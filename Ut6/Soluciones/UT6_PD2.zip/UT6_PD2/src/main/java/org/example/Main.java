package org.example;

public class Main {

    public static void main(String[] args) {
        HashTable<String> hashTable = new HashTable<>(1000);


        double[] loadFactors = {0.70, 0.75, 0.80, 0.85, 0.90, 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99};
        int totalKeys = 1000;

        for (double loadFactor : loadFactors) {
            hashTable.clear();
            int keysToInsert = (int) (totalKeys * loadFactor);
            int successfulSearches = keysToInsert / 2;


            for (int i = 0; i < keysToInsert; i++) {
                String key = "key" + i;
                hashTable.insert(key, key);
            }


            int totalSuccessfulComparisons = 0;
            for (int i = 0; i < successfulSearches; i++) {
                String key = "key" + i;
                totalSuccessfulComparisons += hashTable.searchComparisons(key);
            }


            int totalUnsuccessfulComparisons = 0;
            for (int i = successfulSearches; i < totalKeys; i++) {
                String key = "key" + (i + keysToInsert);
                totalUnsuccessfulComparisons += hashTable.searchComparisons(key);
            }


            double avgInsertComparisons = hashTable.getInsertComparisons() / (double) keysToInsert;
            double avgSuccessfulSearchComparisons = totalSuccessfulComparisons / (double) successfulSearches;
            double avgUnsuccessfulSearchComparisons = totalUnsuccessfulComparisons / (double) (totalKeys - successfulSearches);


            System.out.printf("Factor de carga: %.2f%%, Prom. Comparaciones Inserción: %.2f, Prom. Comp. Búsqueda exitosa: %.2f, Prom. Comp. Búsqueda sin éxito: %.2f%n",
                    loadFactor * 100, avgInsertComparisons, avgSuccessfulSearchComparisons, avgUnsuccessfulSearchComparisons);
        }
    }
}
