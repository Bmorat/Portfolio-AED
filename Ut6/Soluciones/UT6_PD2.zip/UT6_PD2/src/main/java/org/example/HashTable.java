package org.example;

public class HashTable<T> {
    private T[] table;
    private int size;
    private int insertComparisons;

    public HashTable(int capacity) {
        table = (T[]) new Object[capacity];
        size = 0;
        insertComparisons = 0;
    }

    public void insert(String key, T value) {
        int index = hash(key);
        int comparisons = 0;
        while (table[index] != null) {
            index = (index + 1) % table.length;
            comparisons++;
        }
        table[index] = value;
        size++;
        insertComparisons += comparisons;
    }

    public int searchComparisons(String key) {
        int index = hash(key);
        int comparisons = 0;
        while (table[index] != null) {
            comparisons++;
            if (table[index].equals(key)) {
                return comparisons;
            }
            index = (index + 1) % table.length;
        }
        return comparisons;
    }

    public int getInsertComparisons() {
        return insertComparisons;
    }

    public void clear() {
        table = (T[]) new Object[table.length];
        size = 0;
        insertComparisons = 0;
    }

    private int hash(String key) {
        return Math.abs(key.hashCode() % table.length);
    }
}


