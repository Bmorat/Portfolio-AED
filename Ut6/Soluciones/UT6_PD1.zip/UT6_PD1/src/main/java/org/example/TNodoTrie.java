package org.example;

import java.util.HashMap;
import java.util.Map;

public class TNodoTrie {
    private Map<Character, TNodoTrie> hijos;
    private boolean esPalabra;

    public TNodoTrie() {
        hijos = new HashMap<>();
        esPalabra = false;
    }

    public void insertar(String palabra) {
        TNodoTrie nodo = this;
        for (char c : palabra.toCharArray()) {
            nodo.hijos.putIfAbsent(c, new TNodoTrie());
            nodo = nodo.hijos.get(c);
        }
        nodo.esPalabra = true;
    }

    public boolean buscar(String palabra) {
        TNodoTrie nodo = this;
        for (char c : palabra.toCharArray()) {
            nodo = nodo.hijos.get(c);
            if (nodo == null) {
                return false;
            }
        }
        return nodo.esPalabra;
    }

    public void predecir(String prefijo, StringBuilder resultado) {
        TNodoTrie nodo = this;
        for (char c : prefijo.toCharArray()) {
            nodo = nodo.hijos.get(c);
            if (nodo == null) {
                return;
            }
        }
        nodo.predecirRecursivo(prefijo, resultado);
    }

    private void predecirRecursivo(String prefijo, StringBuilder resultado) {
        if (esPalabra) {
            resultado.append(prefijo).append("\n");
        }
        for (Map.Entry<Character, TNodoTrie> entrada : hijos.entrySet()) {
            entrada.getValue().predecirRecursivo(prefijo + entrada.getKey(), resultado);
        }
    }
}

