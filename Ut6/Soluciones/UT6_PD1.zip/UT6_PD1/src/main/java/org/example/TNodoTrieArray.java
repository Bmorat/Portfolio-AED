package org.example;

class TNodoTrieArray {
    private TNodoTrieArray[] hijos;
    private boolean esPalabra;

    public TNodoTrieArray() {
        hijos = new TNodoTrieArray[26]; // Solo para letras minúsculas
        esPalabra = false;
    }

    public void insertar(String palabra) {
        TNodoTrieArray nodo = this;
        for (char c : palabra.toCharArray()) {
            int indice = c - 'a';
            if (nodo.hijos[indice] == null) {
                nodo.hijos[indice] = new TNodoTrieArray();
            }
            nodo = nodo.hijos[indice];
        }
        nodo.esPalabra = true;
    }

    public boolean buscar(String palabra) {
        TNodoTrieArray nodo = this;
        for (char c : palabra.toCharArray()) {
            int indice = c - 'a';
            if (nodo.hijos[indice] == null) {
                return false;
            }
            nodo = nodo.hijos[indice];
        }
        return nodo.esPalabra;
    }
}

class TrieArray {
    private TNodoTrieArray raiz;

    public TrieArray() {
        raiz = new TNodoTrieArray();
    }

    public void insertar(String palabra) {
        raiz.insertar(palabra);
    }

    public boolean buscar(String palabra) {
        return raiz.buscar(palabra);
    }
}

