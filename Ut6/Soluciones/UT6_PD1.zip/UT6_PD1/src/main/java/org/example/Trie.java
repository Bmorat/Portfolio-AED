package org.example;

public class Trie {
    private TNodoTrie raiz;

    public Trie() {
        raiz = new TNodoTrie();
    }

    public void insertar(String palabra) {
        raiz.insertar(palabra);
    }

    public boolean buscar(String palabra) {
        return raiz.buscar(palabra);
    }

    public String predecir(String prefijo) {
        StringBuilder resultado = new StringBuilder();
        raiz.predecir(prefijo, resultado);
        return resultado.toString();
    }
}
