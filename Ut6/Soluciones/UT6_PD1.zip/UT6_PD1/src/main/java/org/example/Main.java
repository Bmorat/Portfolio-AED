package org.example;

public class Main {
    public static void main(String[] args) {
        Trie trieConHashMap = new Trie();

        String[] palabras = {"hola", "holanda", "holaquetal", "hondo", "hoja", "huevo"};
        for (String palabra : palabras) {
            trieConHashMap.insertar(palabra);
        }

        System.out.println("Búsqueda de 'hola': " + trieConHashMap.buscar("hola"));
        System.out.println("Predicción para 'ho': ");
        System.out.println(trieConHashMap.predecir("ho"));

        compararImplementaciones(palabras);
    }

    private static void compararImplementaciones(String[] palabras) {
        long inicio, fin;

        // Trie con HashMap
        Trie trieConHashMap = new Trie();
        inicio = System.nanoTime();
        for (String palabra : palabras) {
            trieConHashMap.insertar(palabra);
        }
        fin = System.nanoTime();
        System.out.println("Tiempo de inserción con HashMap: " + (fin - inicio) + " nanosegundos");

        inicio = System.nanoTime();
        for (String palabra : palabras) {
            trieConHashMap.buscar(palabra);
        }
        fin = System.nanoTime();
        System.out.println("Tiempo de búsqueda con HashMap: " + (fin - inicio) + " nanosegundos");

        // Trie con Array
        TrieArray trieConArray = new TrieArray();
        inicio = System.nanoTime();
        for (String palabra : palabras) {
            trieConArray.insertar(palabra);
        }
        fin = System.nanoTime();
        System.out.println("Tiempo de inserción con Array: " + (fin - inicio) + " nanosegundos");

        inicio = System.nanoTime();
        for (String palabra : palabras) {
            trieConArray.buscar(palabra);
        }
        fin = System.nanoTime();
        System.out.println("Tiempo de búsqueda con Array: " + (fin - inicio) + " nanosegundos");
    }
}

