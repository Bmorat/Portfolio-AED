package org.example;

public class ArbolBB<T> implements IArbolBB<T> {
    private IElementoAB<T> raiz;

    public ArbolBB() {
        this.raiz = null;
    }

    public boolean insertar(IElementoAB<T> unElemento) {
        if (raiz == null) {
            raiz = unElemento;
            return true;
        } else {
            return raiz.insertar(unElemento);
        }
    }

    public IElementoAB<T> buscar(Comparable unaEtiqueta) {
        if (raiz == null) {
            return null;
        } else {
            return raiz.buscar(unaEtiqueta);
        }
    }

    public String preOrden() {
        if (raiz != null) {
            return raiz.preOrden();
        } else {
            return "";
        }
    }

    public String inOrden() {
        if (raiz != null) {
            return raiz.inOrden();
        } else {
            return "";
        }
    }

    public String postOrden() {
        if (raiz != null) {
            return raiz.postOrden();
        } else {
            return "";
        }
    }

    public void eliminar(Comparable unaEtiqueta) {
        // Implementación del método de eliminación si es necesario.
    }
}

