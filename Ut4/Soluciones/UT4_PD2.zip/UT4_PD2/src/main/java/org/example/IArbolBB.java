package org.example;

public interface IArbolBB<T> {
    boolean insertar(IElementoAB<T> unElemento);
    IElementoAB<T> buscar(Comparable unaEtiqueta);
    String preOrden();
    String inOrden();
    String postOrden();
    void eliminar(Comparable unaEtiqueta);
}

