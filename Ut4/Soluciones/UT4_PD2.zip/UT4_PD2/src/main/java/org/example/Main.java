package org.example;

public class Main {
    public static void main(String[] args) {
        ArbolBB<Integer> arbol = new ArbolBB<>();
        cargarArbolDesdeArchivo("src/main/resources/claves.txt", arbol);

        System.out.println("Preorden:");
        System.out.println(arbol.preOrden());

        System.out.println("Inorden:");
        System.out.println(arbol.inOrden());

        System.out.println("Postorden:");
        System.out.println(arbol.postOrden());

        buscarClaves(arbol, new int[]{10635, 4567, 12, 8978});
    }

    private static void cargarArbolDesdeArchivo(String nombreArchivo, ArbolBB<Integer> arbol) {
        String[] lineas = ManejadorArchivosGenerico.leerArchivo(nombreArchivo);
        for (String linea : lineas) {
            Integer clave = Integer.parseInt(linea.trim());
            IElementoAB<Integer> elemento = new ElementoAB<>(clave, clave);
            arbol.insertar(elemento);
        }
    }

    private static void buscarClaves(ArbolBB<Integer> arbol, int[] claves) {
        for (int clave : claves) {
            IElementoAB<Integer> resultado = arbol.buscar(clave);
            if (resultado != null) {
                System.out.println("Clave " + clave + " encontrada en el árbol.");
            } else {
                System.out.println("Clave " + clave + " no encontrada en el árbol.");
            }
        }
    }
}

