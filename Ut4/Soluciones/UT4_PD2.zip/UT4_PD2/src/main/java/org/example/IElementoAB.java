package org.example;

public interface IElementoAB<T> {
    T getDatos();
    Comparable getEtiqueta();
    IElementoAB<T> getHijoIzq();
    IElementoAB<T> getHijoDer();
    void setHijoIzq(IElementoAB<T> elemento);
    void setHijoDer(IElementoAB<T> elemento);
    IElementoAB<T> buscar(Comparable unaEtiqueta);
    boolean insertar(IElementoAB<T> elemento);
    String preOrden();
    String inOrden();
    String postOrden();
}

