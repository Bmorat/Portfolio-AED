package org.example;

public class ElementoAB<T> implements IElementoAB<T> {
    private Comparable etiqueta;
    private T datos;
    private IElementoAB<T> hijoIzq;
    private IElementoAB<T> hijoDer;

    public ElementoAB(Comparable etiqueta, T datos) {
        this.etiqueta = etiqueta;
        this.datos = datos;
        this.hijoIzq = null;
        this.hijoDer = null;
    }

    public T getDatos() {
        return datos;
    }

    public Comparable getEtiqueta() {
        return etiqueta;
    }

    public IElementoAB<T> getHijoIzq() {
        return hijoIzq;
    }

    public IElementoAB<T> getHijoDer() {
        return hijoDer;
    }

    public void setHijoIzq(IElementoAB<T> elemento) {
        this.hijoIzq = elemento;
    }

    public void setHijoDer(IElementoAB<T> elemento) {
        this.hijoDer = elemento;
    }

    public IElementoAB<T> buscar(Comparable unaEtiqueta) {
        if (this.etiqueta.equals(unaEtiqueta)) {
            return this;
        } else if (unaEtiqueta.compareTo(this.etiqueta) < 0) {
            if (this.hijoIzq != null) {
                return this.hijoIzq.buscar(unaEtiqueta);
            } else {
                return null;
            }
        } else {
            if (this.hijoDer != null) {
                return this.hijoDer.buscar(unaEtiqueta);
            } else {
                return null;
            }
        }
    }

    public boolean insertar(IElementoAB<T> elemento) {
        if (elemento.getEtiqueta().compareTo(this.etiqueta) < 0) {
            if (this.hijoIzq == null) {
                this.hijoIzq = elemento;
                return true;
            } else {
                return this.hijoIzq.insertar(elemento);
            }
        } else if (elemento.getEtiqueta().compareTo(this.etiqueta) > 0) {
            if (this.hijoDer == null) {
                this.hijoDer = elemento;
                return true;
            } else {
                return this.hijoDer.insertar(elemento);
            }
        } else {
            return false;
        }
    }

    public String preOrden() {
        StringBuilder resultado = new StringBuilder();
        resultado.append(this.etiqueta).append(" ");
        if (this.hijoIzq != null) {
            resultado.append(this.hijoIzq.preOrden());
        }
        if (this.hijoDer != null) {
            resultado.append(this.hijoDer.preOrden());
        }
        return resultado.toString();
    }

    public String inOrden() {
        StringBuilder resultado = new StringBuilder();
        if (this.hijoIzq != null) {
            resultado.append(this.hijoIzq.inOrden());
        }
        resultado.append(this.etiqueta).append(" ");
        if (this.hijoDer != null) {
            resultado.append(this.hijoDer.inOrden());
        }
        return resultado.toString();
    }

    public String postOrden() {
        StringBuilder resultado = new StringBuilder();
        if (this.hijoIzq != null) {
            resultado.append(this.hijoIzq.postOrden());
        }
        if (this.hijoDer != null) {
            resultado.append(this.hijoDer.postOrden());
        }
        resultado.append(this.etiqueta).append(" ");
        return resultado.toString();
    }
}
