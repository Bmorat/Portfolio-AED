package org.example;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ManejadorArchivosGenerico {
    public static void escribirArchivo(String nombreCompletoArchivo, String[] listaLineasArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreCompletoArchivo))) {
            for (String linea : listaLineasArchivo) {
                writer.write(linea);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo " + nombreCompletoArchivo);
            e.printStackTrace();
        }
    }

    public static String[] leerArchivo(String nombreCompletoArchivo) {
        List<String> listaLineasArchivo = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreCompletoArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                listaLineasArchivo.add(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo " + nombreCompletoArchivo);
            e.printStackTrace();
        }
        return listaLineasArchivo.toArray(new String[0]);
    }
}

