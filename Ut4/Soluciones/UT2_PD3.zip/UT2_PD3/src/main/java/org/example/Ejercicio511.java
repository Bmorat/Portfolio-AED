package org.example;

public class Ejercicio511 {
    public static int ordenacionPorSeleccion(int[] arr) {
        int comparaciones = 0;

        for (int i = 0; i < arr.length - 1; i++) {
            int min_idx = i;
            for (int j = i + 1; j < arr.length; j++) {
                comparaciones++;
                if (arr[j] < arr[min_idx]) {
                    min_idx = j;
                }
            }

            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
        }
        return comparaciones;
    }

    public static void main(String[] args) {
        int[] arr = {5, 3, 1, 9, 7, 4, 6, 8, 2};
        System.out.println("Comparaciones necesarias: " + ordenacionPorSeleccion(arr));
    }
}

