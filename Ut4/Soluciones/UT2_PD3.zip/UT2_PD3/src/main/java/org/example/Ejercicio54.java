package org.example;

public class Ejercicio54 {
    public static int busquedaBinaria(int[] arr, int clave) {
        int inicio = 0;
        int fin = arr.length - 1;
        int comparaciones = 0;

        while (inicio <= fin) {
            comparaciones++;
            int medio = (inicio + fin) / 2;
            if (arr[medio] == clave) {
                return comparaciones;
            } else if (arr[medio] < clave) {
                inicio = medio + 1;
            } else {
                fin = medio - 1;
            }
        }
        return comparaciones;
    }

    public static void main(String[] args) {
        int[] arr = {1, 3, 5, 7, 9, 11, 13, 15};
        int clave = 5;
        System.out.println("Comparaciones necesarias: " + busquedaBinaria(arr, clave));
    }
}

