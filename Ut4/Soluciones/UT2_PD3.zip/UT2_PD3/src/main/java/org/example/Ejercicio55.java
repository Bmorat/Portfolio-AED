package org.example;

public class Ejercicio55 {
    public static int busquedaSecuencial(int[] arr, int clave) {
        int comparaciones = 0;

        for (int i = 0; i < arr.length; i++) {
            comparaciones++;
            if (arr[i] == clave) {
                return comparaciones;
            }
        }
        return comparaciones;
    }

    public static void main(String[] args) {
        int[] arr = {1, 3, 5, 7, 9, 11, 13, 15};
        int clave = 5;
        System.out.println("Comparaciones necesarias: " + busquedaSecuencial(arr, clave));
    }
}

