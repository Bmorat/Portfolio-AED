package org.example;

public class Ejercicio56 {
    public static int ordenacionPorInsercion(int[] arr) {
        int comparaciones = 0;

        for (int i = 1; i < arr.length; i++) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                comparaciones++;
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
        return comparaciones;
    }

    public static void main(String[] args) {
        int[] arr = {5, 3, 1, 9, 7, 4, 6, 8, 2};
        System.out.println("Comparaciones necesarias: " + ordenacionPorInsercion(arr));
    }
}

