package org.example;

import java.util.Stack;

public class ArbolBinario {
    Nodo raiz;

    ArbolBinario() {
        raiz = null;
    }

    // Método para construir el árbol a partir de una expresión en notación prefija
    public Nodo construirArbol(String[] expresion) {
        Stack<Nodo> pila = new Stack<>();
        for (int i = expresion.length - 1; i >= 0; i--) {
            if (!esOperador(expresion[i])) {
                pila.push(new Nodo(expresion[i]));
            } else {
                Nodo nodo = new Nodo(expresion[i]);
                nodo.izquierdo = pila.pop();
                nodo.derecho = pila.pop();
                pila.push(nodo);
            }
        }
        raiz = pila.peek();
        return raiz;
    }

    // Método para evaluar el árbol de expresión
    public int evaluar(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }

        if (!esOperador(nodo.valor)) {
            return Integer.parseInt(nodo.valor);
        }

        int izquierdo = evaluar(nodo.izquierdo);
        int derecho = evaluar(nodo.derecho);

        switch (nodo.valor) {
            case "+":
                return izquierdo + derecho;
            case "-":
                return izquierdo - derecho;
            case "*":
                return izquierdo * derecho;
            case "/":
                if (derecho == 0) {
                    throw new UnsupportedOperationException("División por cero");
                }
                return izquierdo / derecho;
        }
        return 0;
    }

    private boolean esOperador(String c) {
        return c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/");
    }

    // Método para sustituir variables en el árbol
    public void sustituirVariable(Nodo nodo, String variable, int valor) {
        if (nodo == null) {
            return;
        }
        if (nodo.valor.equals(variable)) {
            nodo.valor = Integer.toString(valor);
        }
        sustituirVariable(nodo.izquierdo, variable, valor);
        sustituirVariable(nodo.derecho, variable, valor);
    }
}

