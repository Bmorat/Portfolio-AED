package org.example;

public class Main {
    public static void main(String[] args) {
        String[] expresion = {"+", "*", "a", "b", "-", "c", "d"};
        ArbolBinario arbol = new ArbolBinario();
        Nodo raiz = arbol.construirArbol(expresion);

        // Sustituir variables
        arbol.sustituirVariable(raiz, "a", 3);
        arbol.sustituirVariable(raiz, "b", 2);
        arbol.sustituirVariable(raiz, "c", 5);
        arbol.sustituirVariable(raiz, "d", 1);

        // Evaluar el árbol de expresión
        int resultado = arbol.evaluar(raiz);
        System.out.println("El resultado de la expresión es: " + resultado);
    }
}
