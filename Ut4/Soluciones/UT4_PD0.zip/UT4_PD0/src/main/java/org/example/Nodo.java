package org.example;

public class Nodo {
    String valor;
    Nodo izquierdo, derecho;

    Nodo(String item) {
        valor = item;
        izquierdo = derecho = null;
    }
}
