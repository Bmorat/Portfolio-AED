package org.example;

public int algoritmoCuatro(Comparable unaEti) {
    int A = 0;
    if (unaEti.compareTo(etiqueta) < 0) {
        if (hijoIzquierdo != null) {
            A = hijoIzquierdo.algoritmoCuatro(unaEti);
        }
    }
    if (unaEti.compareTo(etiqueta) > 0) {
        if (hijoDerecho != null) {
            A = hijoDerecho.algoritmoCuatro(unaEti);
        }
    }
    if (unaEti.compareTo(etiqueta) == 0) {
        A = 1;
    }
    return A;
}

