package org.example;

public TipoElementoAB encuentraLinealTres(String nombreAtributo, String valorAtributo) {
    if (nombreAtributo.equals("etiqueta") && valorAtributo.equals(etiqueta.toString())) {
        return this;
    }
    TipoElementoAB encontrado = null;
    if (hijoIzquierdo != null) {
        encontrado = hijoIzquierdo.encuentraLinealTres(nombreAtributo, valorAtributo);
    }
    if (encontrado == null && hijoDerecho != null) {
        encontrado = hijoDerecho.encuentraLinealTres(nombreAtributo, valorAtributo);
    }
    return encontrado;
}

