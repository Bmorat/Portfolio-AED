package org.example;

public boolean encuentraLinealUno(String nombreAtributo, String valorAtributo) {
    if (nombreAtributo.equals("etiqueta") && valorAtributo.equals(etiqueta.toString())) {
        return true;
    }
    boolean encontrado = false;
    if (hijoIzquierdo != null) {
        encontrado = hijoIzquierdo.encuentraLinealUno(nombreAtributo, valorAtributo);
    }
    if (!encontrado && hijoDerecho != null) {
        encontrado = hijoDerecho.encuentraLinealUno(nombreAtributo, valorAtributo);
    }
    return encontrado;
}

