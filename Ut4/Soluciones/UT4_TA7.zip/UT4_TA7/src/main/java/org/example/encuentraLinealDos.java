package org.example;

public boolean encuentraLinealDos(String nombreAtributo, String valorAtributo) {
    if (nombreAtributo.equals("etiqueta") && valorAtributo.equals(etiqueta.toString())) {
        return true;
    }
    if (hijoIzquierdo != null && hijoIzquierdo.encuentraLinealDos(nombreAtributo, valorAtributo)) {
        return true;
    }
    return hijoDerecho != null && hijoDerecho.encuentraLinealDos(nombreAtributo, valorAtributo);
}

