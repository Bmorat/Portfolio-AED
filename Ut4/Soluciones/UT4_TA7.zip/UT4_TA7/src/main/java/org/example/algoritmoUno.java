package org.example;

public int algoritmoUno() {
    int x = -1;
    int y = -1;
    if (hijoIzquierdo != null) {
        x = hijoIzquierdo.algoritmoUno();
    }
    if (hijoDerecho != null) {
        y = hijoDerecho.algoritmoUno();
    }
    return Math.max(x + 1, y + 1);
}

