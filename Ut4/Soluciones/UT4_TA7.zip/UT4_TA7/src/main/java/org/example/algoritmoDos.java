package org.example;

public int algoritmoDos() {
    int x = 0;
    int y = 0;
    if (hijoIzquierdo == null && hijoDerecho == null) {
        return 0;
    }
    if (hijoIzquierdo != null) {
        x = hijoIzquierdo.algoritmoDos();
    }
    if (hijoDerecho != null) {
        y = hijoDerecho.algoritmoDos();
    }
    return x + y + 1;
}
