package org.example;

public int algoritmoTres() {
    int x = 0;
    int y = 0;
    if (hijoIzquierdo != null) {
        x = hijoIzquierdo.algoritmoTres();
    }
    if (hijoDerecho != null) {
        y = hijoDerecho.algoritmoTres();
    }
    return x + y + (int) etiqueta;
}

