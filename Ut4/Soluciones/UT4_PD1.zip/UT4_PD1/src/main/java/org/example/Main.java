package org.example;

public class Main {
    public static void main(String[] args) {
        ArbolBST arbol = new ArbolBST();
        String[] claves = {"T", "Y", "U", "P", "L", "K", "J", "S", "A", "Z", "X", "C", "V", "N"};
        for (String clave : claves) {
            arbol.insertar(clave);
        }

        System.out.println("Recorrido Inorden:");
        arbol.inorden();
        System.out.println();

        System.out.println("Recorrido Preorden:");
        arbol.preorden();
        System.out.println();

        System.out.println("Recorrido Postorden:");
        arbol.postorden();
        System.out.println();
    }
}
