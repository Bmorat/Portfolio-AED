package org.example;

public class NodoBST {
    String clave;
    NodoBST izquierdo, derecho;

    public NodoBST(String item) {
        clave = item;
        izquierdo = derecho = null;
    }
}

