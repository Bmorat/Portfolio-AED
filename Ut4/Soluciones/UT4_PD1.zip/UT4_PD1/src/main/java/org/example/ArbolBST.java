package org.example;

public class ArbolBST {
    NodoBST raiz;

    public ArbolBST() {
        raiz = null;
    }

    public void insertar(String clave) {
        raiz = insertarRec(raiz, clave);
    }

    private NodoBST insertarRec(NodoBST raiz, String clave) {
        if (raiz == null) {
            raiz = new NodoBST(clave);
            return raiz;
        }
        if (clave.compareTo(raiz.clave) < 0) {
            raiz.izquierdo = insertarRec(raiz.izquierdo, clave);
        } else if (clave.compareTo(raiz.clave) > 0) {
            raiz.derecho = insertarRec(raiz.derecho, clave);
        }
        return raiz;
    }

    public void inorden() {
        inordenRec(raiz);
    }

    private void inordenRec(NodoBST raiz) {
        if (raiz != null) {
            inordenRec(raiz.izquierdo);
            System.out.print(raiz.clave + " ");
            inordenRec(raiz.derecho);
        }
    }

    public void preorden() {
        preordenRec(raiz);
    }

    private void preordenRec(NodoBST raiz) {
        if (raiz != null) {
            System.out.print(raiz.clave + " ");
            preordenRec(raiz.izquierdo);
            preordenRec(raiz.derecho);
        }
    }

    public void postorden() {
        postordenRec(raiz);
    }

    private void postordenRec(NodoBST raiz) {
        if (raiz != null) {
            postordenRec(raiz.izquierdo);
            postordenRec(raiz.derecho);
            System.out.print(raiz.clave + " ");
        }
    }
}

