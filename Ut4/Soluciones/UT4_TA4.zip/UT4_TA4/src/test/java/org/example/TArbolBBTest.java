package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class TArbolBBTest {

    @Test
    public void testInsertarYBuscar() {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(new TElementoAB<>(50, 50));
        arbol.insertar(new TElementoAB<>(30, 30));
        arbol.insertar(new TElementoAB<>(70, 70));
        arbol.insertar(new TElementoAB<>(20, 20));
        arbol.insertar(new TElementoAB<>(40, 40));
        arbol.insertar(new TElementoAB<>(60, 60));
        arbol.insertar(new TElementoAB<>(80, 80));

        assertEquals(3, arbol.cantidadHojas());
        assertEquals(1, arbol.nivel(30));
        assertEquals(2, arbol.nivel(20));
        assertEquals(-1, arbol.nivel(100));
    }
}


