package org.example;

public class TArbolBB<T> {
    private TElementoAB<T> raiz;

    public void insertar(TElementoAB<T> unElemento) {
        if (raiz == null) {
            raiz = unElemento;
        } else {
            raiz.insertar(unElemento);
        }
    }

    public int cantidadHojas() {
        if (raiz == null) {
            return 0;
        }
        return raiz.cantidadHojas();
    }

    public int nivel(Comparable etiqueta) {
        if (raiz == null) {
            return -1;
        }
        return raiz.nivel(etiqueta, 0);
    }
}


