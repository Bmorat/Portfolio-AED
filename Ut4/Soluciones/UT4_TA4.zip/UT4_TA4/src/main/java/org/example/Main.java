package org.example;

public class Main {

    public static void main(String[] args) {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        cargarArbolDesdeArchivo("src/main/resources/claves.txt", arbol);

        System.out.println("Cantidad de hojas: " + arbol.cantidadHojas());
        System.out.println("Nivel de la clave 40: " + arbol.nivel(40));
        System.out.println("Nivel de la clave 20: " + arbol.nivel(20));
        System.out.println("Nivel de la clave 100: " + arbol.nivel(100));
    }

    private static void cargarArbolDesdeArchivo(String archivo, TArbolBB<Integer> arbol) {
        String[] lineas = ManejadorArchivosGenerico.leerArchivo(archivo);
        for (String linea : lineas) {
            Integer clave = Integer.parseInt(linea.trim());
            arbol.insertar(new TElementoAB<>(clave, clave));
        }
    }
}



