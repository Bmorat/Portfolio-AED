package org.example;

public class TElementoAB<T> {
    private final Comparable etiqueta;
    private TElementoAB<T> izquierdo;
    private TElementoAB<T> derecho;
    private T datos;

    public TElementoAB(Comparable unaEtiqueta, T unosDatos) {
        etiqueta = unaEtiqueta;
        datos = unosDatos;
    }

    public void insertar(TElementoAB<T> unElemento) {
        if (unElemento.getEtiqueta().compareTo(etiqueta) < 0) {
            if (izquierdo == null) {
                izquierdo = unElemento;
            } else {
                izquierdo.insertar(unElemento);
            }
        } else {
            if (derecho == null) {
                derecho = unElemento;
            } else {
                derecho.insertar(unElemento);
            }
        }
    }

    public int cantidadHojas() {
        int cant = 0;
        if (izquierdo == null && derecho == null) {
            return 1;
        }
        if (izquierdo != null) {
            cant += izquierdo.cantidadHojas();
        }
        if (derecho != null) {
            cant += derecho.cantidadHojas();
        }
        return cant;
    }

    public int nivel(Comparable unaEtiqueta, int nivel) {
        if (etiqueta.compareTo(unaEtiqueta) == 0) {
            return nivel;
        } else if (etiqueta.compareTo(unaEtiqueta) > 0) {
            if (izquierdo != null) {
                return izquierdo.nivel(unaEtiqueta, nivel + 1);
            }
        } else {
            if (derecho != null) {
                return derecho.nivel(unaEtiqueta, nivel + 1);
            }
        }
        return -1;
    }

    public Comparable getEtiqueta() {
        return etiqueta;
    }

    public TElementoAB<T> getIzquierdo() {
        return izquierdo;
    }

    public TElementoAB<T> getDerecho() {
        return derecho;
    }
}


