package org.example;

import java.util.List;

public class TArbolBBTest {
    private TArbolBB<Integer> arbol;

    public void setUp() {
        arbol = new TArbolBB<>();
        arbol.insertar(new TElementoABB<>(50, 50));
        arbol.insertar(new TElementoABB<>(30, 30));
        arbol.insertar(new TElementoABB<>(20, 20));
        arbol.insertar(new TElementoABB<>(40, 40));
        arbol.insertar(new TElementoABB<>(70, 70));
        arbol.insertar(new TElementoABB<>(60, 60));
        arbol.insertar(new TElementoABB<>(80, 80));
    }

    public void testObtenerMenorClave() {
        assert Integer.valueOf(20).equals(arbol.obtenerMenorClave().getEtiqueta());
    }

    public void testObtenerMayorClave() {
        assert Integer.valueOf(80).equals(arbol.obtenerMayorClave().getEtiqueta());
    }

    public void testObtenerClaveInmediataAnterior() {
        assert Integer.valueOf(40).equals(arbol.obtenerClaveInmediataAnterior(50).getEtiqueta());
    }

    public void testContarNodosEnNivel() {
        assert arbol.contarNodosEnNivel(3) == 2;
    }

    public void testListarHojasConNivel() {
        List<String> hojas = arbol.listarHojasConNivel();
        assert hojas.contains("20 (Nivel 3)");
        assert hojas.contains("40 (Nivel 3)");
        assert hojas.contains("60 (Nivel 3)");
        assert hojas.contains("80 (Nivel 3)");
    }

    public void testEsArbolDeBusqueda() {
        assert arbol.esArbolDeBusqueda();
    }
}

