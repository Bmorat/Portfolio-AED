package org.example;

public class Main {
    public static void main(String[] args) {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(new TElementoABB<>(50, 50));
        arbol.insertar(new TElementoABB<>(30, 30));
        arbol.insertar(new TElementoABB<>(20, 20));
        arbol.insertar(new TElementoABB<>(40, 40));
        arbol.insertar(new TElementoABB<>(70, 70));
        arbol.insertar(new TElementoABB<>(60, 60));
        arbol.insertar(new TElementoABB<>(80, 80));

        System.out.println("Menor clave: " + arbol.obtenerMenorClave().getEtiqueta());
        System.out.println("Mayor clave: " + arbol.obtenerMayorClave().getEtiqueta());
        System.out.println("Clave inmediata anterior a 50: " + arbol.obtenerClaveInmediataAnterior(50).getEtiqueta());
        System.out.println("Nodos en nivel 3: " + arbol.contarNodosEnNivel(3));
        System.out.println("Hojas con nivel: " + arbol.listarHojasConNivel());
        System.out.println("¿Es árbol de búsqueda?: " + arbol.esArbolDeBusqueda());
    }
}



