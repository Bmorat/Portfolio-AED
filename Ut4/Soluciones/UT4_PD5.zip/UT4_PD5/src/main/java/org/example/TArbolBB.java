package org.example;

import java.util.LinkedList;
import java.util.List;

public class TArbolBB<T> {
    private TElementoABB<T> raiz;

    public void insertar(TElementoABB<T> unElemento) {
        if (raiz == null) {
            raiz = unElemento;
        } else {
            raiz.insertar(unElemento);
        }
    }

    public TElementoABB<T> obtenerMenorClave() {
        if (raiz == null) {
            return null;
        }
        return raiz.obtenerMenorClave();
    }

    public TElementoABB<T> obtenerMayorClave() {
        if (raiz == null) {
            return null;
        }
        return raiz.obtenerMayorClave();
    }

    public TElementoABB<T> obtenerClaveInmediataAnterior(Comparable clave) {
        if (raiz == null) {
            return null;
        }
        return raiz.obtenerClaveInmediataAnterior(clave);
    }

    public int contarNodosEnNivel(int nivel) {
        if (raiz == null) {
            return 0;
        }
        return raiz.contarNodosEnNivel(nivel);
    }

    public List<String> listarHojasConNivel() {
        List<String> hojas = new LinkedList<>();
        if (raiz != null) {
            raiz.listarHojasConNivel(hojas, 1);
        }
        return hojas;
    }

    public boolean esArbolDeBusqueda() {
        if (raiz == null) {
            return true;
        }
        return raiz.esArbolDeBusqueda();
    }
}


