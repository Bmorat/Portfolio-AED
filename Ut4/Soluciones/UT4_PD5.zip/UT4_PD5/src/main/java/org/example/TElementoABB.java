package org.example;

import java.util.List;

public class TElementoABB<T> {
    private Comparable etiqueta;
    private T datos;
    private TElementoABB<T> izquierdo;
    private TElementoABB<T> derecho;

    public TElementoABB(Comparable unaEtiqueta, T unosDatos) {
        this.etiqueta = unaEtiqueta;
        this.datos = unosDatos;
        this.izquierdo = null;
        this.derecho = null;
    }

    public Comparable getEtiqueta() {
        return etiqueta;
    }

    public TElementoABB<T> getIzquierdo() {
        return izquierdo;
    }

    public TElementoABB<T> getDerecho() {
        return derecho;
    }

    public void setIzquierdo(TElementoABB<T> elemento) {
        this.izquierdo = elemento;
    }

    public void setDerecho(TElementoABB<T> elemento) {
        this.derecho = elemento;
    }

    public void insertar(TElementoABB<T> unElemento) {
        if (unElemento.getEtiqueta().compareTo(this.etiqueta) < 0) {
            if (this.izquierdo == null) {
                this.izquierdo = unElemento;
            } else {
                this.izquierdo.insertar(unElemento);
            }
        } else {
            if (this.derecho == null) {
                this.derecho = unElemento;
            } else {
                this.derecho.insertar(unElemento);
            }
        }
    }

    public TElementoABB<T> obtenerMenorClave() {
        if (this.izquierdo == null) {
            return this;
        } else {
            return this.izquierdo.obtenerMenorClave();
        }
    }

    public TElementoABB<T> obtenerMayorClave() {
        if (this.derecho == null) {
            return this;
        } else {
            return this.derecho.obtenerMayorClave();
        }
    }

    public TElementoABB<T> obtenerClaveInmediataAnterior(Comparable clave) {
        TElementoABB<T> actual = this;
        TElementoABB<T> anterior = null;

        while (actual != null && !actual.getEtiqueta().equals(clave)) {
            if (clave.compareTo(actual.getEtiqueta()) > 0) {
                anterior = actual;
                actual = actual.getDerecho();
            } else {
                actual = actual.getIzquierdo();
            }
        }
        if (actual != null && actual.getIzquierdo() != null) {
            actual = actual.getIzquierdo().obtenerMayorClave();
            anterior = actual;
        }
        return anterior;
    }

    public int contarNodosEnNivel(int nivel) {
        return contarNodosEnNivel(this, 1, nivel);
    }

    private int contarNodosEnNivel(TElementoABB<T> nodo, int nivelActual, int nivelObjetivo) {
        if (nodo == null) {
            return 0;
        }
        if (nivelActual == nivelObjetivo) {
            return 1;
        }
        return contarNodosEnNivel(nodo.getIzquierdo(), nivelActual + 1, nivelObjetivo)
                + contarNodosEnNivel(nodo.getDerecho(), nivelActual + 1, nivelObjetivo);
    }

    public void listarHojasConNivel(List<String> hojas, int nivelActual) {
        if (this.izquierdo == null && this.derecho == null) {
            hojas.add(this.etiqueta + " (Nivel " + nivelActual + ")");
        }
        if (this.izquierdo != null) {
            this.izquierdo.listarHojasConNivel(hojas, nivelActual + 1);
        }
        if (this.derecho != null) {
            this.derecho.listarHojasConNivel(hojas, nivelActual + 1);
        }
    }

    public boolean esArbolDeBusqueda() {
        return esArbolDeBusqueda(this, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private boolean esArbolDeBusqueda(TElementoABB<T> nodo, Comparable min, Comparable max) {
        if (nodo == null) {
            return true;
        }
        if (nodo.getEtiqueta().compareTo(min) <= 0 || nodo.getEtiqueta().compareTo(max) >= 0) {
            return false;
        }
        return esArbolDeBusqueda(nodo.getIzquierdo(), min, nodo.getEtiqueta())
                && esArbolDeBusqueda(nodo.getDerecho(), nodo.getEtiqueta(), max);
    }
}




