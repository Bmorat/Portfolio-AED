package org.example;

public class Ejercicio523 {
    public static int contarInversiones(int[] arr) {
        int inversiones = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] > arr[j]) {
                    inversiones++;
                }
            }
        }
        return inversiones;
    }

    public static void main(String[] args) {
        int[] arr = {2, 4, 1, 3, 5};
        int inversiones = contarInversiones(arr);
        System.out.println("El número de inversiones en el arreglo es: " + inversiones);
    }
}

