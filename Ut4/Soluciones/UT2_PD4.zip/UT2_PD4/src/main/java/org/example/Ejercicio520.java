package org.example;

public class Ejercicio520 {
    public static int encontrarMaximo(int[] arr) {
        int maximo = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > maximo) {
                maximo = arr[i];
            }
        }
        return maximo;
    }

    public static void main(String[] args) {
        int[] arr = {3, 5, 7, 2, 8, 6, 4, 7, 0, 1};
        int maximo = encontrarMaximo(arr);
        System.out.println("El máximo valor en el arreglo es: " + maximo);
    }
}
