
import java.util.Collection;
import java.util.Map;

public interface IGrafoNoDirigido {

 
    public TGrafoNoDirigido Prim();

    public TGrafoNoDirigido Kruskal();
}
