package org.example;

public class Main {
    public static void main(String[] args) {
        TArbolGenerico arbol = new TArbolGenerico();
        arbol.insertar("RECTORÍA", "");
        arbol.insertar("VICERRECTORÍA ADMINISTRATIVA", "RECTORÍA");
        arbol.insertar("VICERRECTORÍA ACADÉMICA", "RECTORÍA");
        arbol.insertar("FACULTAD DE CIENCIAS HUMANAS", "VICERRECTORÍA ACADÉMICA");
        arbol.insertar("DEPARTAMENTO DE INFORMÁTICA Y CIENCIAS DE LA COMPUTACIÓN", "FACULTAD DE CIENCIAS HUMANAS");

        System.out.println(arbol.listarIndentado());
    }
}
