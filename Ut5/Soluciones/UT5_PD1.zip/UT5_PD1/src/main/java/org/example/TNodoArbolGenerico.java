package org.example;

public class TNodoArbolGenerico {
    private String etiqueta;
    private TNodoArbolGenerico primerHijo;
    private TNodoArbolGenerico hermanoDerecho;

    public TNodoArbolGenerico(String etiqueta) {
        this.etiqueta = etiqueta;
        this.primerHijo = null;
        this.hermanoDerecho = null;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setPrimerHijo(TNodoArbolGenerico hijo) {
        this.primerHijo = hijo;
    }

    public TNodoArbolGenerico getPrimerHijo() {
        return primerHijo;
    }

    public void setHermanoDerecho(TNodoArbolGenerico hermano) {
        this.hermanoDerecho = hermano;
    }

    public TNodoArbolGenerico getHermanoDerecho() {
        return hermanoDerecho;
    }

    public TNodoArbolGenerico buscar(String unaEtiqueta) {
        if (this.etiqueta.equals(unaEtiqueta)) {
            return this;
        }
        TNodoArbolGenerico hijo = this.primerHijo;
        while (hijo != null) {
            TNodoArbolGenerico resultado = hijo.buscar(unaEtiqueta);
            if (resultado != null) {
                return resultado;
            }
            hijo = hijo.getHermanoDerecho();
        }
        return null;
    }

    public boolean insertar(String unaEtiqueta, String etiquetaPadre) {
        TNodoArbolGenerico padre = buscar(etiquetaPadre);
        if (padre != null) {
            TNodoArbolGenerico nuevoNodo = new TNodoArbolGenerico(unaEtiqueta);
            TNodoArbolGenerico hijo = padre.getPrimerHijo();
            if (hijo == null) {
                padre.setPrimerHijo(nuevoNodo);
            } else {
                while (hijo.getHermanoDerecho() != null) {
                    hijo = hijo.getHermanoDerecho();
                }
                hijo.setHermanoDerecho(nuevoNodo);
            }
            return true;
        }
        return false;
    }

    public String listarIndentado(String indentacion) {
        StringBuilder resultado = new StringBuilder(indentacion + etiqueta + "\n");
        TNodoArbolGenerico hijo = primerHijo;
        while (hijo != null) {
            resultado.append(hijo.listarIndentado(indentacion + "  "));
            hijo = hijo.getHermanoDerecho();
        }
        return resultado.toString();
    }
}
