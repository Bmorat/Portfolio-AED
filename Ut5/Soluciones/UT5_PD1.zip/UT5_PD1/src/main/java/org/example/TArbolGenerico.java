package org.example;

public class TArbolGenerico {
    private TNodoArbolGenerico raiz;

    public TArbolGenerico() {
        this.raiz = null;
    }

    public boolean insertar(String unaEtiqueta, String etiquetaPadre) {
        if (raiz == null) {
            raiz = new TNodoArbolGenerico(unaEtiqueta);
            return true;
        }
        return raiz.insertar(unaEtiqueta, etiquetaPadre);
    }

    public TNodoArbolGenerico buscar(String unaEtiqueta) {
        if (raiz != null) {
            return raiz.buscar(unaEtiqueta);
        }
        return null;
    }

    public String listarIndentado() {
        if (raiz != null) {
            return raiz.listarIndentado("");
        }
        return "";
    }
}

