import org.example.TArbolGenerico;
import org.example.TNodoArbolGenerico;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TArbolGenericoTest {
    @Test
    public void testInsertarYBuscar() {
        TArbolGenerico arbol = new TArbolGenerico();
        assertTrue(arbol.insertar("RECTORÍA", ""));
        assertTrue(arbol.insertar("VICERRECTORÍA ADMINISTRATIVA", "RECTORÍA"));
        assertTrue(arbol.insertar("VICERRECTORÍA ACADÉMICA", "RECTORÍA"));
        assertTrue(arbol.insertar("FACULTAD DE CIENCIAS HUMANAS", "VICERRECTORÍA ACADÉMICA"));
        assertTrue(arbol.insertar("DEPARTAMENTO DE INFORMÁTICA Y CIENCIAS DE LA COMPUTACIÓN", "FACULTAD DE CIENCIAS HUMANAS"));

        TNodoArbolGenerico nodo = arbol.buscar("FACULTAD DE CIENCIAS HUMANAS");
        assertNotNull(nodo);
        assertEquals("FACULTAD DE CIENCIAS HUMANAS", nodo.getEtiqueta());

        nodo = arbol.buscar("DEPARTAMENTO DE INFORMÁTICA Y CIENCIAS DE LA COMPUTACIÓN");
        assertNotNull(nodo);
        assertEquals("DEPARTAMENTO DE INFORMÁTICA Y CIENCIAS DE LA COMPUTACIÓN", nodo.getEtiqueta());

        nodo = arbol.buscar("NO_EXISTE");
        assertNull(nodo);
    }

    @Test
    public void testListarIndentado() {
        TArbolGenerico arbol = new TArbolGenerico();
        arbol.insertar("RECTORÍA", "");
        arbol.insertar("VICERRECTORÍA ADMINISTRATIVA", "RECTORÍA");
        arbol.insertar("VICERRECTORÍA ACADÉMICA", "RECTORÍA");
        arbol.insertar("FACULTAD DE CIENCIAS HUMANAS", "VICERRECTORÍA ACADÉMICA");
        arbol.insertar("DEPARTAMENTO DE INFORMÁTICA Y CIENCIAS DE LA COMPUTACIÓN", "FACULTAD DE CIENCIAS HUMANAS");

        String expected =
                "RECTORÍA\n" +
                        "  VICERRECTORÍA ADMINISTRATIVA\n" +
                        "  VICERRECTORÍA ACADÉMICA\n" +
                        "    FACULTAD DE CIENCIAS HUMANAS\n" +
                        "      DEPARTAMENTO DE INFORMÁTICA Y CIENCIAS DE LA COMPUTACIÓN\n";
        assertEquals(expected, arbol.listarIndentado());
    }
}

