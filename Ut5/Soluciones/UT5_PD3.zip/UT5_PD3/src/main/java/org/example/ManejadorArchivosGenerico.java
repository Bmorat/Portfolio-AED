package org.example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ManejadorArchivosGenerico {

    public static String[] leerArchivo(String nombreCompletoArchivo) {
        ArrayList<String> listaLineasArchivo = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(nombreCompletoArchivo))) {
            String lineaActual;
            while ((lineaActual = br.readLine()) != null) {
                listaLineasArchivo.add(lineaActual);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo " + nombreCompletoArchivo);
            e.printStackTrace();
        }
        return listaLineasArchivo.toArray(new String[0]);
    }

    public static void escribirArchivo(String nombreCompletoArchivo, String[] listaLineasArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreCompletoArchivo))) {
            for (String linea : listaLineasArchivo) {
                bw.write(linea);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo " + nombreCompletoArchivo);
            e.printStackTrace();
        }
    }
}

