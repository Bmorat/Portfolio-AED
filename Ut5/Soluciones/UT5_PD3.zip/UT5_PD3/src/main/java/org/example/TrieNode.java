package org.example;

import java.util.ArrayList;
import java.util.List;

public class TrieNode {
    public TrieNode[] children;
    public boolean isEndOfWord;
    public List<Integer> pages;

    public TrieNode() {
        children = new TrieNode[256];
        isEndOfWord = false;
        pages = new ArrayList<>();
    }
}






