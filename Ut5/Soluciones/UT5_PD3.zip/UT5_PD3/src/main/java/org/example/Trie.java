package org.example;

public class Trie {
    private final TrieNode root;
    public int comparisons;

    public Trie() {
        root = new TrieNode();
        comparisons = 0;
    }

    public void insert(String key) {
        TrieNode node = root;
        for (int level = 0; level < key.length(); level++) {
            int index = key.charAt(level);
            if (node.children[index] == null) {
                node.children[index] = new TrieNode();
            }
            node = node.children[index];
        }
        node.isEndOfWord = true;
    }

    public TrieNode search(String key) {
        TrieNode node = root;
        comparisons = 0;
        for (int level = 0; level < key.length(); level++) {
            int index = key.charAt(level);
            comparisons++;
            if (node.children[index] == null) {
                return null;
            }
            node = node.children[index];
        }
        return (node != null && node.isEndOfWord) ? node : null;
    }
}

