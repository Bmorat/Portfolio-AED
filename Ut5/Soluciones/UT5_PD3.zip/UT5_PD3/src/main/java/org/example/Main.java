package org.example;

public class Main {
    public static void main(String[] args) {
        Trie trie = new Trie();

        // Insertar palabras en el Trie
        String[] palabras = ManejadorArchivosGenerico.leerArchivo("src/main/resources/palabras.txt");
        for (String palabra : palabras) {
            trie.insert(palabra.trim());
        }

        // Buscar palabras en el Trie
        String[] palabrasABuscar = ManejadorArchivosGenerico.leerArchivo("src/main/resources/palabrasAbuscar.txt");
        for (String palabra : palabrasABuscar) {
            TrieNode result = trie.search(palabra.trim());
            if (result != null && result.isEndOfWord) {
                System.out.println("Palabra encontrada: " + palabra.trim());
                System.out.println("Páginas: " + result.pages);
                System.out.println("Comparaciones: " + trie.comparisons);
            } else {
                System.out.println("Palabra no encontrada");
                System.out.println("Comparaciones: " + trie.comparisons);
            }
        }
    }
}


