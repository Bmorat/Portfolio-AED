package org.example;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Trie trie = new Trie();

        // Datos de prueba
        trie.insert("ala", Arrays.asList(1, 3, 88));
        trie.insert("alimaña", Arrays.asList(11, 22));
        trie.insert("alabastro", Arrays.asList(4));
        trie.insert("perro", Arrays.asList(5, 8));
        trie.insert("pera", Arrays.asList(7, 12));
        trie.insert("alimento", Arrays.asList(9));
        trie.insert("casa", Arrays.asList(11, 13));
        trie.insert("casada", Arrays.asList(1));
        trie.insert("cazar", Arrays.asList(33));
        trie.insert("programa", Arrays.asList(22, 67));
        trie.insert("programación", Arrays.asList(15));
        trie.insert("programar", Arrays.asList(15, 16));

        // Búsquedas
        String palabraBuscar = "programa";
        List<Integer> paginas = trie.search(palabraBuscar);
        if (!paginas.isEmpty()) {
            System.out.println("La palabra '" + palabraBuscar + "' se encuentra en las páginas: " + paginas);
        } else {
            System.out.println("La palabra '" + palabraBuscar + "' no se encuentra en el libro.");
        }

        palabraBuscar = "proselitismo";
        paginas = trie.search(palabraBuscar);
        if (!paginas.isEmpty()) {
            System.out.println("La palabra '" + palabraBuscar + "' se encuentra en las páginas: " + paginas);
        } else {
            System.out.println("La palabra '" + palabraBuscar + "' no se encuentra en el libro.");
        }
    }
}


