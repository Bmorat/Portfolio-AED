package org.example;

import java.util.ArrayList;
import java.util.List;

class TrieNode {
    TrieNode[] children;
    List<Integer> pages;

    public TrieNode() {
        children = new TrieNode[256]; // Soporta todos los caracteres ASCII.
        pages = new ArrayList<>();
    }
}


