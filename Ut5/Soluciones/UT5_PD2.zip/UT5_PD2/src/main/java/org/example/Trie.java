package org.example;

import java.util.ArrayList;
import java.util.List;

public class Trie {
    private TrieNode root;

    public Trie() {
        root = new TrieNode();
    }

    public void insert(String word, List<Integer> pages) {
        TrieNode node = root;
        for (char c : word.toCharArray()) {
            int index = (int) c;
            if (node.children[index] == null) {
                node.children[index] = new TrieNode();
            }
            node = node.children[index];
        }
        node.pages.addAll(pages);
    }

    public List<Integer> search(String word) {
        TrieNode node = root;
        for (char c : word.toCharArray()) {
            int index = (int) c;
            if (node.children[index] == null) {
                return new ArrayList<>();
            }
            node = node.children[index];
        }
        return node.pages;
    }
}


