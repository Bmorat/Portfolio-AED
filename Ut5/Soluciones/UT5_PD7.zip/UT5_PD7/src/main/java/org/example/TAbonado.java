package org.example;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ernesto
 */
public class TAbonado implements Comparable<TAbonado> {
    private String telefono;
    private String nombre;

    public TAbonado(String telefono, String nombre) {
        this.telefono = telefono;
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public int compareTo(TAbonado o) {
        return this.nombre.compareTo(o.nombre);
    }
}
