package org.example;

import java.io.*;
import java.util.ArrayList;

public class ManejadorArchivosGenerico {

	public static String[] leerArchivo(String nombreCompletoArchivo) {
		FileReader fr;
		ArrayList<String> listaLineasArchivo = new ArrayList<>();
		try {
			fr = new FileReader(nombreCompletoArchivo);
			BufferedReader br = new BufferedReader(fr);
			String lineaActual = br.readLine();
			while (lineaActual != null) {
				listaLineasArchivo.add(lineaActual);
				lineaActual = br.readLine();
			}
			br.close();
			fr.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error al leer el archivo " + nombreCompletoArchivo);
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error al leer el archivo " + nombreCompletoArchivo);
			e.printStackTrace();
		}
		return listaLineasArchivo.toArray(new String[0]);
	}

	public static void escribirArchivo(String nombreCompletoArchivo, String[] listaLineasArchivo) {
		FileWriter fw;
		try {
			fw = new FileWriter(nombreCompletoArchivo, true);
			BufferedWriter bw = new BufferedWriter(fw);
			for (String lineaActual : listaLineasArchivo) {
				bw.write(lineaActual);
				bw.newLine();
			}
			bw.close();
			fw.close();
		} catch (IOException e) {
			System.out.println("Error al escribir el archivo " + nombreCompletoArchivo);
			e.printStackTrace();
		}
	}
}

