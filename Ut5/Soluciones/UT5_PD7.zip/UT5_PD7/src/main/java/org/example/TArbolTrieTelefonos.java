package org.example;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TArbolTrieTelefonos implements IArbolTrieTelefonos {
    private TNodoTrieTelefonos raiz;

    public TArbolTrieTelefonos() {
        raiz = new TNodoTrieTelefonos();
    }

    @Override
    public void insertar(String telefono, String nombre) {
        raiz.insertar(telefono, nombre);
    }

    @Override
    public List<TAbonado> buscarTelefonos(String codigoPais, String codigoArea) {
        List<TAbonado> abonados = new ArrayList<>();
        raiz.buscarTelefonos(codigoPais, codigoArea, abonados);
        Collections.sort(abonados);
        return abonados;
    }
}

