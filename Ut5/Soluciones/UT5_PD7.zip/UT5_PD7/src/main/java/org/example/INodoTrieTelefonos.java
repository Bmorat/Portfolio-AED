package org.example;

import java.util.List;

public interface INodoTrieTelefonos {
    void insertar(String telefono, String nombre);
    void buscarTelefonos(String codigoPais, String codigoArea, List<TAbonado> abonados);
}

