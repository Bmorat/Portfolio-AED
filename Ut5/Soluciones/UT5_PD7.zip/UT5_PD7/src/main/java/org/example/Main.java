package org.example;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        IArbolTrieTelefonos trie = new TArbolTrieTelefonos();

        // Cargar abonados
        String[] abonados = ManejadorArchivosGenerico.leerArchivo("src/main/resources/abonados.txt");
        for (String abonado : abonados) {
            String[] datos = abonado.split(",");
            if (datos.length == 2) {  // Verificación de que los datos tienen el formato correcto
                trie.insertar(datos[0], datos[1]);
            } else {
                System.out.println("Formato incorrecto en abonados: " + abonado);
            }
        }

        // Cargar y procesar códigos
        String[] codigos = ManejadorArchivosGenerico.leerArchivo("src/main/resources/codigos1.txt");
        String codigoPais = "";
        String codigoArea = "";
        for (String codigo : codigos) {
            if (codigo.startsWith("CODIGO PAIS:")) {
                codigoPais = codigo.split(": ")[1];
            } else if (codigo.startsWith("CODIGO AREA:")) {
                codigoArea = codigo.split(": ")[1];
            }
        }

        if (!codigoPais.isEmpty() && !codigoArea.isEmpty()) {
            List<TAbonado> abonadosEncontrados = trie.buscarTelefonos(codigoPais, codigoArea);
            String[] salida = new String[abonadosEncontrados.size()];
            for (int i = 0; i < abonadosEncontrados.size(); i++) {
                TAbonado abonado = abonadosEncontrados.get(i);
                salida[i] = abonado.getNombre() + "," + abonado.getTelefono();
            }
            ManejadorArchivosGenerico.escribirArchivo("src/main/resources/salida.txt", salida);
        } else {
            System.out.println("Código país o código área no especificado correctamente.");
        }
    }
}





