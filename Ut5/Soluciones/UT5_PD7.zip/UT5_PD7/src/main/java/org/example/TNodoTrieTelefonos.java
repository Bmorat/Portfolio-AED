package org.example;


import java.util.List;

public class TNodoTrieTelefonos implements INodoTrieTelefonos {
    private static final int CANT_CHR_ABECEDARIO = 10;
    private TNodoTrieTelefonos[] hijos;
    private boolean esTelefono;
    private String nombre;

    public TNodoTrieTelefonos() {
        hijos = new TNodoTrieTelefonos[CANT_CHR_ABECEDARIO];
        esTelefono = false;
        nombre = null;
    }

    @Override
    public void insertar(String telefono, String nombre) {
        TNodoTrieTelefonos nodo = this;
        for (char c : telefono.toCharArray()) {
            int indice = c - '0';
            if (nodo.hijos[indice] == null) {
                nodo.hijos[indice] = new TNodoTrieTelefonos();
            }
            nodo = nodo.hijos[indice];
        }
        nodo.esTelefono = true;
        nodo.nombre = nombre;
    }

    @Override
    public void buscarTelefonos(String codigoPais, String codigoArea, List<TAbonado> abonados) {
        TNodoTrieTelefonos nodo = this;
        String codigo = codigoPais + codigoArea;
        for (char c : codigo.toCharArray()) {
            int indice = c - '0';
            if (nodo.hijos[indice] == null) {
                return;
            }
            nodo = nodo.hijos[indice];
        }
        nodo.buscarAbonados(abonados, codigo);
    }

    private void buscarAbonados(List<TAbonado> abonados, String prefijo) {
        if (this.esTelefono) {
            abonados.add(new TAbonado(prefijo, this.nombre));
        }
        for (int i = 0; i < hijos.length; i++) {
            if (hijos[i] != null) {
                hijos[i].buscarAbonados(abonados, prefijo + i);
            }
        }
    }
}
