package org.example;

public class Main {
    public static void main(String[] args) {
        Lista<String> lista = new Lista<>();

        lista.insertar("1", "A");
        lista.insertar("2", "B");
        lista.insertar("3", "C");

        System.out.println("Lista después de insertar elementos:");
        System.out.println(lista.imprimir());

        Nodo<String> nodoBuscado = lista.buscar("2");
        System.out.println("Buscando el nodo con clave '2':");
        if (nodoBuscado != null) {
            nodoBuscado.imprimir();
        } else {
            System.out.println("Nodo no encontrado.");
        }

        System.out.println("Eliminando el nodo con clave '2': " + lista.eliminar("2"));
        System.out.println("Lista después de eliminar el nodo con clave '2':");
        System.out.println(lista.imprimir());

        System.out.println("Cantidad de elementos en la lista: " + lista.cantElementos());
    }
}
