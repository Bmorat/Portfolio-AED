package org.example;

public class Lista<T> implements ILista<T> {
    private Nodo<T> primero;

    public Lista() {
        primero = null;
    }

    @Override
    public void insertar(Nodo<T> nodo) {
        if (esVacia()) {
            primero = nodo;
        } else {
            Nodo<T> temp = primero;
            while (temp.getSiguiente() != null) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(nodo);
        }
    }

    @Override
    public void insertar(Comparable etiqueta, T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(etiqueta, dato);
        insertar(nuevoNodo);
    }

    @Override
    public Nodo<T> buscar(Comparable clave) {
        Nodo<T> temp = primero;
        while (temp != null && !temp.getEtiqueta().equals(clave)) {
            temp = temp.getSiguiente();
        }
        return temp;
    }

    @Override
    public boolean eliminar(Comparable clave) {
        if (esVacia()) {
            return false;
        }

        if (primero.getEtiqueta().equals(clave)) {
            primero = primero.getSiguiente();
            return true;
        }

        Nodo<T> temp = primero;
        while (temp.getSiguiente() != null && !temp.getSiguiente().getEtiqueta().equals(clave)) {
            temp = temp.getSiguiente();
        }

        if (temp.getSiguiente() == null) {
            return false;
        }

        temp.setSiguiente(temp.getSiguiente().getSiguiente());
        return true;
    }

    @Override
    public String imprimir() {
        StringBuilder sb = new StringBuilder();
        Nodo<T> temp = primero;
        while (temp != null) {
            sb.append(temp.getEtiqueta().toString()).append(" ");
            temp = temp.getSiguiente();
        }
        return sb.toString().trim();
    }

    @Override
    public String imprimir(String separador) {
        StringBuilder sb = new StringBuilder();
        Nodo<T> temp = primero;
        while (temp != null) {
            sb.append(temp.getEtiqueta().toString()).append(separador);
            temp = temp.getSiguiente();
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - separador.length()) : "";
    }

    @Override
    public int cantElementos() {
        int count = 0;
        Nodo<T> temp = primero;
        while (temp != null) {
            count++;
            temp = temp.getSiguiente();
        }
        return count;
    }

    @Override
    public boolean esVacia() {
        return primero == null;
    }

    @Override
    public void setPrimero(Nodo<T> unNodo) {
        this.primero = unNodo;
    }
}

