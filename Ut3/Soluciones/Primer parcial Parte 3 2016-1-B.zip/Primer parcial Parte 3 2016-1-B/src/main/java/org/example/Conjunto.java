package org.example;

import java.util.LinkedList;

public class Conjunto<T> implements IConjunto<T> {
    private LinkedList<T> elementos;

    public Conjunto() {
        this.elementos = new LinkedList<>();
    }

    @Override
    public void insertar(T elemento) {
        if (!elementos.contains(elemento)) {
            elementos.add(elemento);
        }
    }

    @Override
    public IConjunto<T> complemento(IConjunto<T> conjuntoUniversal) {
        Conjunto<T> resultado = new Conjunto<>();
        for (T elemento : ((Conjunto<T>) conjuntoUniversal).elementos) {
            if (!elementos.contains(elemento)) {
                resultado.insertar(elemento);
            }
        }
        return resultado;
    }

    @Override
    public void imprimir(String separador) {
        System.out.println(String.join(separador, elementos.toString().replace("[", "").replace("]", "").split(", ")));
    }

    public LinkedList<T> getElementos() {
        return elementos;
    }
}

