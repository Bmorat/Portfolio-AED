package org.example;

public interface IConjunto<T> {
    void insertar(T elemento);
    IConjunto<T> complemento(IConjunto<T> conjuntoUniversal);
    void imprimir(String separador);
}

