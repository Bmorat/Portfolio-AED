package org.example;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Curso AED1 = new Curso("AED1");

        String[] alumnosAED1 = ManejadorArchivosGenerico.leerArchivo("src/main/resources/alumnosAED1.txt");
        for (String alumno : alumnosAED1) {
            AED1.agregarAlumno(Integer.parseInt(alumno.trim()));
        }

        IConjunto<Integer> habilitados = new Conjunto<>();
        String[] alumnosHabilitados = ManejadorArchivosGenerico.leerArchivo("src/main/resources/habilitados.txt");
        for (String alumno : alumnosHabilitados) {
            habilitados.insertar(Integer.parseInt(alumno.trim()));
        }

        IConjunto<Integer> noInscriptos = AED1.noInscriptos(habilitados);
        List<String> salida = new ArrayList<>();
        for (Integer alumno : ((Conjunto<Integer>) noInscriptos).getElementos()) {
            salida.add(alumno.toString());
        }
        ManejadorArchivosGenerico.escribirArchivo("src/main/resources/salidaComplemento.txt", salida.toArray(new String[0]));

        System.out.println("Diferencia simétrica:");
        noInscriptos.imprimir(",");
    }
}
