package org.example;

public class Main {
    public static void main(String[] args) {
        Almacen almacen = new Almacen();

        // Actualizar el stock desde el archivo de altas de prueba
        double valorAgregadoPrueba = almacen.actualizarStockDesdeArchivo("altasPrueba.txt");
        System.out.println("Valor total agregado al stock (prueba): " + valorAgregadoPrueba);

        // Listar productos después de las altas de prueba
        System.out.println("Productos en el almacén después de las altas (prueba):");
        almacen.listarProductos();

        // Vender productos desde el archivo de ventas de prueba
        double valorReducidoPrueba = almacen.venderDesdeArchivo("ventasPrueba.txt");
        System.out.println("Valor total reducido del stock (prueba): " + valorReducidoPrueba);

        // Listar productos después de las ventas de prueba
        System.out.println("Productos en el almacén después de las ventas (prueba):");
        almacen.listarProductos();

        // Actualizar el stock desde el archivo de altas reales
        double valorAgregado = almacen.actualizarStockDesdeArchivo("altas.txt");
        System.out.println("Valor total agregado al stock (real): " + valorAgregado);

        // Listar productos después de las altas reales
        System.out.println("Productos en el almacén después de las altas (real):");
        almacen.listarProductos();

        // Vender productos desde el archivo de ventas reales
        double valorReducido = almacen.venderDesdeArchivo("ventas.txt");
        System.out.println("Valor total reducido del stock (real): " + valorReducido);

        // Listar productos después de las ventas reales
        System.out.println("Productos en el almacén después de las ventas (real):");
        almacen.listarProductos();
    }
}
