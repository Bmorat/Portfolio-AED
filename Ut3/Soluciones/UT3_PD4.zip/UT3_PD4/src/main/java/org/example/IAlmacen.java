package org.example;

public interface IAlmacen {
    void incorporarProducto(Producto producto);
    void agregarStock(String codigo, int cantidad);
    Producto buscarProducto(String codigo);
    boolean eliminarProducto(String codigo);
    void listarProductos();
    double actualizarStockDesdeArchivo(String nombreArchivo);
    double venderDesdeArchivo(String nombreArchivo);
}
