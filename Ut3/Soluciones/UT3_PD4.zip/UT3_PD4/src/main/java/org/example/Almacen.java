package org.example;

import java.io.*;
import java.net.URL;
import java.util.*;

public class Almacen implements IAlmacen {
    private List<Producto> productos;

    public Almacen() {
        this.productos = new ArrayList<>();
    }

    @Override
    public void incorporarProducto(Producto producto) {
        productos.add(producto);
    }

    @Override
    public void agregarStock(String codigo, int cantidad) {
        Producto producto = buscarProducto(codigo);
        if (producto != null) {
            producto.agregarCantidad(cantidad);
        }
    }

    @Override
    public Producto buscarProducto(String codigo) {
        for (Producto producto : productos) {
            if (producto.getCodigo().equals(codigo)) {
                return producto;
            }
        }
        return null;
    }

    @Override
    public boolean eliminarProducto(String codigo) {
        Producto producto = buscarProducto(codigo);
        if (producto != null) {
            productos.remove(producto);
            return true;
        }
        return false;
    }

    @Override
    public void listarProductos() {
        productos.sort(Comparator.comparing(Producto::getNombre));
        for (Producto producto : productos) {
            System.out.println("Nombre: " + producto.getNombre() + ", Código: " + producto.getCodigo() + ", Precio: " + producto.getPrecioUnitario() + ", Cantidad: " + producto.getCantidad());
        }
    }

    @Override
    public double actualizarStockDesdeArchivo(String nombreArchivo) {
        double valorTotal = 0.0;
        try (BufferedReader br = new BufferedReader(new FileReader(getFileFromResource(nombreArchivo)))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                try {
                    String[] datos = linea.split(",");
                    String codigo = datos[0];
                    String nombre = datos[1].replaceAll("\"", "");
                    double precio = Double.parseDouble(datos[2]);
                    int cantidad = Integer.parseInt(datos[3]);

                    Producto producto = buscarProducto(codigo);
                    if (producto == null) {
                        producto = new Producto(codigo, nombre, precio, cantidad);
                        incorporarProducto(producto);
                    } else {
                        producto.agregarCantidad(cantidad);
                    }
                    valorTotal += precio * cantidad;
                } catch (NumberFormatException e) {
                    System.err.println("Error de formato en la línea: " + linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return valorTotal;
    }

    @Override
    public double venderDesdeArchivo(String nombreArchivo) {
        double valorTotal = 0.0;
        try (BufferedReader br = new BufferedReader(new FileReader(getFileFromResource(nombreArchivo)))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                try {
                    String[] datos = linea.split(",");
                    String codigo = datos[0];
                    int cantidad = Integer.parseInt(datos[1]);

                    Producto producto = buscarProducto(codigo);
                    if (producto != null) {
                        int cantidadVendida = Math.min(producto.getCantidad(), cantidad);
                        producto.reducirCantidad(cantidadVendida);
                        valorTotal += producto.getPrecioUnitario() * cantidadVendida;
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Error de formato en la línea: " + linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return valorTotal;
    }

    private File getFileFromResource(String fileName) {
        ClassLoader classLoader = getClass().getClassLoader();
        URL resource = classLoader.getResource(fileName);
        if (resource == null) {
            throw new IllegalArgumentException("File not found! " + fileName);
        } else {
            return new File(resource.getFile());
        }
    }
}


