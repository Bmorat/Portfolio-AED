package org.example;

public interface IProducto {
    String getNombre();
    void setNombre(String nombre);
    String getCodigo();
    void setCodigo(String codigo);
    double getPrecioUnitario();
    void setPrecioUnitario(double precio);
    int getCantidad();
    void setCantidad(int cantidad);
}
