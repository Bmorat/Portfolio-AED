package org.example;

public interface INodo<T> extends Comparable<Comparable> {
    T getDato();
    void setDato(T dato);
    Nodo<T> getSiguiente();
    void setSiguiente(Nodo<T> nodo);
    void imprimir();
    void imprimirEtiqueta();
    Comparable getEtiqueta();
}
