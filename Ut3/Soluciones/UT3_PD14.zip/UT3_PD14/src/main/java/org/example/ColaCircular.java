package org.example;

public class ColaCircular<T> {
    private T[] array;
    private int frente;
    private int fin;
    private int tamanio;
    private int capacidad;

    public ColaCircular(int capacidad) {
        this.capacidad = capacidad;
        array = (T[]) new Object[capacidad];
        frente = 0;
        fin = -1;
        tamanio = 0;
    }

    public boolean esVacia() {
        return tamanio == 0;
    }

    public boolean esLlena() {
        return tamanio == capacidad;
    }

    public void encolar(T dato) {
        if (esLlena()) {
            System.out.println("La cola está llena, no se puede encolar el elemento.");
            return;
        }
        fin = (fin + 1) % capacidad;
        array[fin] = dato;
        tamanio++;
    }

    public T desencolar() {
        if (esVacia()) {
            System.out.println("La cola está vacía, no se puede desencolar ningún elemento.");
            return null;
        }
        T dato = array[frente];
        array[frente] = null;
        frente = (frente + 1) % capacidad;
        tamanio--;
        return dato;
    }

    public T frente() {
        if (esVacia()) {
            return null;
        }
        return array[frente];
    }

    public int tamanio() {
        return tamanio;
    }

    public void imprimir() {
        if (esVacia()) {
            System.out.println("La cola está vacía.");
            return;
        }
        System.out.println("Contenido de la cola circular:");
        for (int i = 0; i < tamanio; i++) {
            int index = (frente + i) % capacidad;
            System.out.print(array[index] + " ");
        }
        System.out.println();
    }
}
