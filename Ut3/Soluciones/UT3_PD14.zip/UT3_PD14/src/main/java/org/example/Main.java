package org.example;

public class Main {
    public static void main(String[] args) {
        ColaCircular<String> cola = new ColaCircular<>(5);

        cola.encolar("A");
        cola.encolar("B");
        cola.encolar("C");
        cola.encolar("D");
        cola.encolar("E");

        cola.imprimir();

        System.out.println("Elemento desencolado: " + cola.desencolar());
        cola.imprimir();

        cola.encolar("F");
        cola.imprimir();

        System.out.println("Elemento desencolado: " + cola.desencolar());
        cola.imprimir();
    }
}
