package org.example;

import java.util.HashSet;
import java.util.Set;

public class Conjunto<T> {
    private Lista<T> elementos;

    public Conjunto() {
        elementos = new Lista<>();
    }

    public void agregar(T elemento) {
        if (!contiene(elemento)) {
            elementos.insertar(new Nodo<>(elemento));
        }
    }

    public boolean contiene(T elemento) {
        Nodo<T> actual = elementos.getPrimero();
        while (actual != null) {
            if (actual.getDato().equals(elemento)) {
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }

    public Conjunto<T> union(Conjunto<T> otroConjunto) {
        Conjunto<T> resultado = new Conjunto<>();
        Nodo<T> actual = this.elementos.getPrimero();

        while (actual != null) {
            resultado.agregar(actual.getDato());
            actual = actual.getSiguiente();
        }

        actual = otroConjunto.elementos.getPrimero();
        while (actual != null) {
            resultado.agregar(actual.getDato());
            actual = actual.getSiguiente();
        }

        return resultado;
    }

    public Conjunto<T> interseccion(Conjunto<T> otroConjunto) {
        Conjunto<T> resultado = new Conjunto<>();
        Nodo<T> actual = this.elementos.getPrimero();

        while (actual != null) {
            if (otroConjunto.contiene(actual.getDato())) {
                resultado.agregar(actual.getDato());
            }
            actual = actual.getSiguiente();
        }

        return resultado;
    }

    public void imprimir() {
        Nodo<T> actual = elementos.getPrimero();
        while (actual != null) {
            System.out.print(actual.getDato() + " ");
            actual = actual.getSiguiente();
        }
        System.out.println();
    }
}
