package org.example;

public class Main {
    public static void main(String[] args) {
        Conjunto<Integer> conjuntoA = new Conjunto<>();
        Conjunto<Integer> conjuntoB = new Conjunto<>();

        conjuntoA.agregar(1);
        conjuntoA.agregar(2);
        conjuntoA.agregar(3);

        conjuntoB.agregar(3);
        conjuntoB.agregar(4);
        conjuntoB.agregar(5);

        Conjunto<Integer> union = conjuntoA.union(conjuntoB);
        Conjunto<Integer> interseccion = conjuntoA.interseccion(conjuntoB);

        System.out.print("Conjunto A: ");
        conjuntoA.imprimir();
        System.out.print("Conjunto B: ");
        conjuntoB.imprimir();
        System.out.print("Unión: ");
        union.imprimir();
        System.out.print("Intersección: ");
        interseccion.imprimir();
    }
}
