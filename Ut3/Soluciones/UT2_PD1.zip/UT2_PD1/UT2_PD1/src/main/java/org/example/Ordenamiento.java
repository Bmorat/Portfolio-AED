package org.example;

import java.io.*;
import java.util.*;

public class Ordenamiento {

    public static void main(String[] args) {
        try {
            // Leer el archivo
            Scanner scanner = new Scanner(new File("numeros.txt"));
            int N = scanner.nextInt();
            int[] arreglo = new int[N];

            for (int i = 0; i < N; i++) {
                arreglo[i] = scanner.nextInt();
            }

            scanner.close();

            // Contador para las sentencias "si"
            int contador = 0;

            // Implementación del algoritmo
            for (int i = 1; i < N; i++) {
                for (int j = N - 1; j >= i; j--) {
                    if (arreglo[j] < arreglo[j - 1]) {
                        // Intercambia(arreglo[j], arreglo[j - 1])
                        int temp = arreglo[j];
                        arreglo[j] = arreglo[j - 1];
                        arreglo[j - 1] = temp;
                        contador++;
                    }
                }
            }

            // Mostrar resultados
            System.out.println("Largo N: " + N);
            System.out.println("Contador de sentencias 'si': " + contador);
            System.out.println("Primera posición: " + arreglo[0]);
            System.out.println("Última posición: " + arreglo[N - 1]);

        } catch (FileNotFoundException e) {
            System.err.println("Archivo no encontrado.");
        }
    }
}



//1-Función
//Desde i = 1 hasta N-1 hacer
//Desde j = N hasta i+1 hacer
//Si arreglo[j].clave < arreglo[j-1].clave entonces
//Intercambia(arreglo[j], arreglo[j-1])
//Fin si
//Fin desde
//Fin desde
//Fin


//Este programa hace lo siguiente:
//Lee el archivo numeros.txt para obtener el valor de N y los elementos del arreglo.
//Implementa el algoritmo de ordenamiento similar a una versión de Bubble Sort.
//Cuenta las veces que se evalúa la condición si.
//Muestra por consola el tamaño del arreglo, el valor del contador, y los números en la primera y última posición del arreglo ordenado.