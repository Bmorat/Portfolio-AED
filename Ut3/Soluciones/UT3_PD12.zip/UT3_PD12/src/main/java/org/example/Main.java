package org.example;

public class Main {
    public static void main(String[] args) {
        Conjunto<String> basicoIng = cargarConjuntoDesdeArchivo("basico-ing.txt");
        Conjunto<String> basicoEmp = cargarConjuntoDesdeArchivo("basico-emp.txt");

        // Crear curso Integrador 101 (Unión de basicoIng y basicoEmp)
        Conjunto<String> integrador101 = (Conjunto<String>) basicoIng.union(basicoEmp);
        guardarConjuntoEnArchivo(integrador101, "Integrador101.txt");

        // Crear curso Exigente 102 (Intersección de basicoIng y basicoEmp)
        Conjunto<String> exigente102 = (Conjunto<String>) basicoIng.interseccion(basicoEmp);
        guardarConjuntoEnArchivo(exigente102, "Exigente102.txt");

        // Imprimir resultados en la consola
        System.out.println("Alumnos en el curso Integrador 101:");
        System.out.println(integrador101.imprimir("\n"));

        System.out.println("Alumnos en el curso Exigente 102:");
        System.out.println(exigente102.imprimir("\n"));
    }

    public static Conjunto<String> cargarConjuntoDesdeArchivo(String nombreArchivo) {
        Conjunto<String> conjunto = new Conjunto<>();
        String[] lineas = ManejadorArchivosGenerico.leerArchivo(nombreArchivo);
        for (String linea : lineas) {
            String[] partes = linea.split(",");
            String nombre = partes[1].trim();
            conjunto.insertar(partes[0], nombre);
        }
        return conjunto;
    }

    public static void guardarConjuntoEnArchivo(Conjunto<String> conjunto, String nombreArchivo) {
        String[] lineas = new String[conjunto.cantElementos()];
        Nodo<String> actual = conjunto.getPrimero();
        int i = 0;
        while (actual != null) {
            lineas[i] = actual.getEtiqueta() + "," + actual.getDato();
            i++;
            actual = actual.getSiguiente();
        }
        ManejadorArchivosGenerico.escribirArchivo(nombreArchivo, lineas);
    }
}
