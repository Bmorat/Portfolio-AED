package org.example;

public class Conjunto<T> extends Lista<T> implements IConjunto<T> {

    @Override
    public IConjunto<T> union(IConjunto<T> otroConjunto) {
        Conjunto<T> resultado = new Conjunto<>();
        Nodo<T> actual = this.getPrimero();

        while (actual != null) {
            resultado.insertar(actual.clonar());
            actual = actual.getSiguiente();
        }

        actual = ((Conjunto<T>) otroConjunto).getPrimero();
        while (actual != null) {
            if (resultado.buscar(actual.getEtiqueta()) == null) {
                resultado.insertar(actual.clonar());
            }
            actual = actual.getSiguiente();
        }

        return resultado;
    }

    @Override
    public IConjunto<T> interseccion(IConjunto<T> otroConjunto) {
        Conjunto<T> resultado = new Conjunto<>();
        Nodo<T> actual = this.getPrimero();

        while (actual != null) {
            if (((Conjunto<T>) otroConjunto).buscar(actual.getEtiqueta()) != null) {
                resultado.insertar(actual.clonar());
            }
            actual = actual.getSiguiente();
        }

        return resultado;
    }
}

