package org.example;

public interface IConjunto<T> {
    IConjunto<T> union(IConjunto<T> otroConjunto);
    IConjunto<T> interseccion(IConjunto<T> otroConjunto);
}

