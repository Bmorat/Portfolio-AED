package org.example;

public class Main {
    public static void main(String[] args) {
        SucursalManager manager = new SucursalManager();

        // Cargar sucursales desde los archivos simulados
        manager.cargarSucursales("sucursales.txt");
        manager.cargarSucursales("suc1.txt");
        manager.cargarSucursales("suc2.txt");
        manager.cargarSucursales("suc3.txt");

        // Pruebas del ejercicio
        manager.listarSucursales();
        System.out.println("Cantidad de sucursales: " + manager.cantidadSucursales());

        System.out.println("\nAgregar 'Nueva York':");
        manager.agregarSucursal("Nueva York");
        manager.listarSucursales();

        System.out.println("\nBuscar 'Montevideo':");
        boolean encontrada = manager.buscarSucursal("Montevideo");
        System.out.println("Sucursal Montevideo encontrada: " + encontrada);

        System.out.println("\nQuitar 'Montevideo':");
        boolean eliminada = manager.quitarSucursal("Montevideo");
        System.out.println("Sucursal Montevideo eliminada: " + eliminada);

        System.out.println("\nListar todas las sucursales:");
        manager.listarSucursales();

        System.out.println("Cantidad de sucursales: " + manager.cantidadSucursales());
        System.out.println("Directorio de sucursales vacío: " + manager.esVacio());
    }
}
