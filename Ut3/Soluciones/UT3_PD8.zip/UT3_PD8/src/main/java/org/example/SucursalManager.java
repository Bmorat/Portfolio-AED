package org.example;

import java.util.ArrayList;

public class SucursalManager {
    private ArrayList<String> sucursales;

    public SucursalManager() {
        this.sucursales = new ArrayList<>();
    }

    private String leerArchivo(String archivo) {
        switch (archivo) {
            case "sucursales.txt":
                return "Montevideo\nCanelones\nArtigas\nRivera\nMaldonado\nRocha\nPando\nSalto\nPaysandu\nTrinidad\nFlorida\nQuebracho\nColonia\nAcegua\nPiriapolis\n";
            case "suc1.txt":
                return "Dubai\nNueva York\nShanghai\nHong Kong\nChicago\nShenzhen\nTokio\nSingapur\nPanama City\nGuangzhou\nYakarta\nHouston\nChongqing\nBangkok\nLos Angeles\nKuala Lumpur\nBusan\nAtlanta\nNankin\nDoha\nSeul\nAbu Dhabi\nToronto\nManila\nDalian\nWuhan\nMelbourne\nSidney\nMoscu\nDallas\nFrankfurt\nFiladelfia\nIncheon\nTianjin\nPekin\nCiudad de Kuwait\nQingdao\nWuxi\nSuzhou\nMadrid\nSeattle\nMineapolis\nCharlotte\nSharjah\nLa Meca\nEstambul\nMiami\nSan Francisco\nDenver\nCleveland\nOsaka\nHangzhou\nHanoi\nRiad\nNagoya\nMacao\nManama\nBrisbane\nLondres\nXian\nParis\nBoston\nPittsburgh\nCincinnati\nCiudad de Mexico\nCalgary\nMontreal\nCaracas\nMumbai\nTaipei\nKaohsiung\nNanchang\nChangsha\nUlsan\nNanning\nKarachi\nBucheon\nZhongshan\nGold Coast\nPerth\nMilan\nJersey City\nDetroit\nNueva Orleans\nAustin\nIndianapolis\nTulsa\nMobile\nVancouver\nCiudad Ho Chi Minh\nXiamen\nAjman\nYokohama\nKawasaki\nXian\nNingbo\nWenzhou\nUrumqi\nPulau Pinang\nGuiyang\nRamat Gan\nNantong\nDongguan\nChangzhou\nIzumisano\nFoshan\n";
            case "suc2.txt":
                return "Tokio\n";
            case "suc3.txt":
                return "Montreal\nCaracas\nTulsa\nMobile\nVancouver\n";
            default:
                return "";
        }
    }

    public void cargarSucursales(String resourcePath) {
        String contenido = leerArchivo(resourcePath);
        String[] lineas = contenido.split("\n");
        for (String linea : lineas) {
            String ciudad = linea.trim().replace("\uFEFF", "");
            if (!ciudad.isEmpty() && !sucursales.contains(ciudad)) {
                sucursales.add(ciudad);
            }
        }
    }

    public void agregarSucursal(String ciudad) {
        if (!sucursales.contains(ciudad)) {
            sucursales.add(ciudad);
            System.out.println("Sucursal agregada: " + ciudad);
        } else {
            System.out.println("La sucursal ya existe: " + ciudad);
        }
    }

    public boolean buscarSucursal(String ciudad) {
        return sucursales.contains(ciudad);
    }

    public boolean quitarSucursal(String ciudad) {
        if (sucursales.remove(ciudad)) {
            System.out.println("Sucursal eliminada: " + ciudad);
            return true;
        } else {
            System.out.println("La sucursal no existe: " + ciudad);
            return false;
        }
    }

    public void listarSucursales() {
        if (sucursales.isEmpty()) {
            System.out.println("No hay sucursales registradas.");
        } else {
            System.out.println("Sucursales registradas:");
            for (String sucursal : sucursales) {
                System.out.println(sucursal);
            }
        }
    }

    public int cantidadSucursales() {
        return sucursales.size();
    }

    public boolean esVacio() {
        return sucursales.isEmpty();
    }
}


