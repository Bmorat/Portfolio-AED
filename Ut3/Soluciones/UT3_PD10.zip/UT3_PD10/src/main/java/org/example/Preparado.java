package org.example;

class Par {
    int suero;
    int farmaco;

    public Par(int suero, int farmaco) {
        this.suero = suero;
        this.farmaco = farmaco;
    }
}

class Preparado {
    private Lista<Integer> listaBlanca;
    private Lista<Par> listaNegra;

    public Preparado() {
        this.listaBlanca = new Lista<>();
        this.listaNegra = new Lista<>();
    }

    public void cargarListaBlanca(String[] lineas) {
        for (String id : lineas) {
            listaBlanca.insertar(new Nodo<>(Integer.parseInt(id), Integer.parseInt(id)));
        }
    }

    public void cargarListaNegra(String[] lineas) {
        for (String linea : lineas) {
            String[] partes = linea.split(",");
            int suero = Integer.parseInt(partes[0]);
            int farmaco = Integer.parseInt(partes[1]);
            listaNegra.insertar(new Nodo<>(suero, new Par(suero, farmaco)));
        }
    }

    public boolean preparadoViable(int identificadorSuero, Lista<Integer> farmacos) {
        Nodo<Integer> actual = farmacos.getPrimero();
        while (actual != null) {
            int idFarmaco = actual.getDato();
            if (listaBlanca.buscar(idFarmaco) == null) {
                Nodo<Par> temp = listaNegra.getPrimero();
                while (temp != null) {
                    if (temp.getDato().suero == identificadorSuero && temp.getDato().farmaco == idFarmaco) {
                        return false;
                    }
                    temp = temp.getSiguiente();
                }
            }
            actual = actual.getSiguiente();
        }
        return true;
    }
}


