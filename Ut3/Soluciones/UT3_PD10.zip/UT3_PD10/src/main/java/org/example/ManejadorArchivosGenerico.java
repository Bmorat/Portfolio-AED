package org.example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ManejadorArchivosGenerico {

    public static void escribirArchivo(String nombreCompletoArchivo, String[] listaLineasArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreCompletoArchivo))) {
            for (String lineaActual : listaLineasArchivo) {
                bw.write(lineaActual);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo " + nombreCompletoArchivo);
            e.printStackTrace();
        }
    }

    public static String[] leerArchivo(String nombreArchivo) {
        ArrayList<String> listaLineasArchivo = new ArrayList<>();
        try (InputStream is = ManejadorArchivosGenerico.class.getResourceAsStream("/" + nombreArchivo);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String lineaActual = br.readLine();
            while (lineaActual != null) {
                listaLineasArchivo.add(lineaActual);
                lineaActual = br.readLine();
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo " + nombreArchivo);
            e.printStackTrace();
        }
        return listaLineasArchivo.toArray(new String[0]);
    }

    public static String filtrarPalabra(String unaPalabra) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < unaPalabra.length(); i++) {
            char caracter = unaPalabra.charAt(i);
            if ((caracter >= 'A' && caracter <= 'Z') || (caracter >= 'a' && caracter <= 'z')) {
                sb.append(caracter);
            }
        }
        return sb.toString();
    }
}


