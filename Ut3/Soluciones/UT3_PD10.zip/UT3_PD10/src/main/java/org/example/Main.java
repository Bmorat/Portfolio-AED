package org.example;


public class Main {
    public static void main(String[] args) {
        String[] listaBlanca = ManejadorArchivosGenerico.leerArchivo("listablanca.txt");
        String[] listaNegra = ManejadorArchivosGenerico.leerArchivo("listanegra.txt");
        String[] sueros = ManejadorArchivosGenerico.leerArchivo("Sueros.txt");

        Preparado preparado = new Preparado();
        preparado.cargarListaBlanca(listaBlanca);
        preparado.cargarListaNegra(listaNegra);

        Lista<Integer> farmacos = new Lista<>();
        farmacos.insertar(new Nodo<>(1, 1));
        farmacos.insertar(new Nodo<>(12, 12));
        farmacos.insertar(new Nodo<>(31, 31));
        farmacos.insertar(new Nodo<>(36, 36));
        farmacos.insertar(new Nodo<>(40, 40));

        boolean esViable = preparado.preparadoViable(13, farmacos);
        System.out.println("El preparado es viable: " + esViable);

        // Imprimir sueros
        for (String suero : sueros) {
            System.out.println(suero);
        }
    }
}

