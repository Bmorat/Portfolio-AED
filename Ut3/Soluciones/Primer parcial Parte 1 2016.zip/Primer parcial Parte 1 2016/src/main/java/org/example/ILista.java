package org.example;

public interface ILista<T> {
    void insertar(T elemento);
    boolean pertenece(T elemento);
    void eliminar(T elemento);
    void imprimir();
}

