package org.example;

import java.util.LinkedList;

public class Lista<T> implements ILista<T> {
    private LinkedList<T> elementos;

    public Lista() {
        this.elementos = new LinkedList<>();
    }

    @Override
    public void insertar(T elemento) {
        if (!pertenece(elemento)) {
            elementos.add(elemento);
        }
    }

    @Override
    public boolean pertenece(T elemento) {
        return elementos.contains(elemento);
    }

    @Override
    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }

    @Override
    public void imprimir() {
        for (T elemento : elementos) {
            System.out.print(elemento + " ");
        }
        System.out.println();
    }

    public LinkedList<T> getElementos() {
        return elementos;
    }
}
