package org.example;

public class Conjunto<T> implements IConjunto<T> {
    private ILista<T> elementos;

    public Conjunto() {
        this.elementos = new Lista<>();
    }

    @Override
    public void insertar(T elemento) {
        elementos.insertar(elemento);
    }

    @Override
    public IConjunto<T> diferenciaSimetrica(IConjunto<T> otroConjunto) {
        Conjunto<T> resultado = new Conjunto<>();
        for (T elemento : ((Lista<T>) elementos).getElementos()) {
            if (!((Lista<T>) ((Conjunto<T>) otroConjunto).elementos).pertenece(elemento)) {
                resultado.insertar(elemento);
            }
        }
        for (T elemento : ((Lista<T>) ((Conjunto<T>) otroConjunto).elementos).getElementos()) {
            if (!((Lista<T>) elementos).pertenece(elemento)) {
                resultado.insertar(elemento);
            }
        }
        return resultado;
    }

    @Override
    public IConjunto<T> complemento(IConjunto<T> conjuntoUniversal) {
        Conjunto<T> resultado = new Conjunto<>();
        for (T elemento : ((Lista<T>) ((Conjunto<T>) conjuntoUniversal).elementos).getElementos()) {
            if (!((Lista<T>) elementos).pertenece(elemento)) {
                resultado.insertar(elemento);
            }
        }
        return resultado;
    }

    @Override
    public void imprimir() {
        elementos.imprimir();
    }
}

