package org.example;

public interface IConjunto<T> {
    void insertar(T elemento);
    IConjunto<T> diferenciaSimetrica(IConjunto<T> otroConjunto);
    IConjunto<T> complemento(IConjunto<T> conjuntoUniversal);
    void imprimir();
}
