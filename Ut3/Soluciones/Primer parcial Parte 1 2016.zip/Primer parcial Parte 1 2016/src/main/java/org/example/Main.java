package org.example;

public class Main {
    public static void main(String[] args) {
        // Creación de conjuntos de prueba
        IConjunto<Integer> conjuntoA = new Conjunto<>();
        IConjunto<Integer> conjuntoB = new Conjunto<>();
        IConjunto<Integer> conjuntoUniversal = new Conjunto<>();

        // Añadir elementos a los conjuntos
        conjuntoA.insertar(1);
        conjuntoA.insertar(2);
        conjuntoA.insertar(3);

        conjuntoB.insertar(3);
        conjuntoB.insertar(4);
        conjuntoB.insertar(5);

        conjuntoUniversal.insertar(1);
        conjuntoUniversal.insertar(2);
        conjuntoUniversal.insertar(3);
        conjuntoUniversal.insertar(4);
        conjuntoUniversal.insertar(5);
        conjuntoUniversal.insertar(6);

        // Diferencia simétrica
        IConjunto<Integer> diferenciaSimetrica = conjuntoA.diferenciaSimetrica(conjuntoB);
        System.out.print("Diferencia simétrica: ");
        diferenciaSimetrica.imprimir();

        // Complemento
        IConjunto<Integer> complemento = conjuntoA.complemento(conjuntoUniversal);
        System.out.print("Complemento: ");
        complemento.imprimir();
    }
}
