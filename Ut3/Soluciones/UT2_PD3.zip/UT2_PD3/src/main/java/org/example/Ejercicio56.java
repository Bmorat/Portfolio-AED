package org.example;

import java.util.Arrays;

public class Ejercicio56 {
    public static void main(String[] args) {
        int[] numeros = {5, 3, 8, 4, 2, 7, 1, 10};
        Arrays.sort(numeros);
        System.out.println("Arreglo ordenado: " + Arrays.toString(numeros));
    }
}

