package org.example;

// Ejercicio 5.10 - Factorial de un número
public class Ejercicio510 {
    public static void main(String[] args) {
        int numero = 5;
        int factorial = calcularFactorial(numero);
        System.out.println("El factorial de " + numero + " es: " + factorial);
    }

    public static int calcularFactorial(int n) {
        if (n == 0) return 1;
        return n * calcularFactorial(n - 1);
    }
}
