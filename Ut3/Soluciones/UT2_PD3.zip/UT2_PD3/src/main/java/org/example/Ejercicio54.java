package org.example;


public class Ejercicio54 {
    public static void main(String[] args) {
        // Ejemplo de implementación de un algoritmo simple
        int[] numeros = {5, 3, 8, 4, 2, 7, 1, 10};
        int suma = sumarArreglo(numeros);
        System.out.println("La suma del arreglo es: " + suma);
    }

    public static int sumarArreglo(int[] arreglo) {
        int suma = 0;
        for (int num : arreglo) {
            suma += num;
        }
        return suma;
    }
}
