package org.example;

public class Ejercicio55 {
    public static void main(String[] args) {
        int[] numeros = {5, 3, 8, 4, 2, 7, 1, 10};
        int objetivo = 7;
        boolean encontrado = buscarNumero(numeros, objetivo);
        System.out.println("Número " + objetivo + " encontrado: " + encontrado);
    }

    public static boolean buscarNumero(int[] arreglo, int objetivo) {
        for (int num : arreglo) {
            if (num == objetivo) {
                return true;
            }
        }
        return false;
    }
}

