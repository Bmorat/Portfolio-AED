package org.example;

class NodoPila {
    char dato;
    NodoPila siguiente;

    public NodoPila(char dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}

class Pila {
    private NodoPila cima;

    public Pila() {
        this.cima = null;
    }

    public void push(char dato) {
        NodoPila nuevoNodo = new NodoPila(dato);
        nuevoNodo.siguiente = cima;
        cima = nuevoNodo;
    }

    public char pop() {
        if (cima == null) {
            return '\0'; // Retorna un caracter nulo si la pila está vacía
        }
        char dato = cima.dato;
        cima = cima.siguiente;
        return dato;
    }

    public boolean esVacia() {
        return cima == null;
    }
}

class Expresion {
    private char[] listaDeEntrada;

    public Expresion(String entrada) {
        this.listaDeEntrada = entrada.toCharArray();
    }

    public boolean controlCorchetes() {
        Pila pila = new Pila();
        for (char ch : listaDeEntrada) {
            if (ch == '{') {
                pila.push(ch);
            } else if (ch == '}') {
                if (pila.esVacia()) {
                    return false; // Si encuentra un corchete de cierre sin un correspondiente de apertura
                }
                pila.pop();
            }
        }
        return pila.esVacia(); // Si la pila está vacía al final, la secuencia es correcta
    }
}
