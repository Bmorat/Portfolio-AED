package org.example;

public class Main {
    public static void main(String[] args) {
        Expresion expresion1 = new Expresion("{}{{}}");
        Expresion expresion2 = new Expresion("{{}{{}");

        System.out.println("Expresion 1: " + "{}{{}}");
        System.out.println("¿Es correcta?: " + expresion1.controlCorchetes());

        System.out.println("Expresion 2: " + "{{}{{}");
        System.out.println("¿Es correcta?: " + expresion2.controlCorchetes());

        // Más casos de prueba
        Expresion expresion3 = new Expresion("{{}}{}");
        Expresion expresion4 = new Expresion("{}{}{}{}");
        Expresion expresion5 = new Expresion("{{{{{{{{{{}}}}}}}}}}");

        System.out.println("Expresion 3: " + "{{}}{}");
        System.out.println("¿Es correcta?: " + expresion3.controlCorchetes());

        System.out.println("Expresion 4: " + "{}{}{}{}");
        System.out.println("¿Es correcta?: " + expresion4.controlCorchetes());

        System.out.println("Expresion 5: " + "{{{{{{{{{{}}}}}}}}}}");
        System.out.println("¿Es correcta?: " + expresion5.controlCorchetes());

        Expresion expresion6 = new Expresion("{{{{{{{{{{}}}}}}}}}");
        System.out.println("Expresion 6: " + "{{{{{{{{{{}}}}}}}}}");
        System.out.println("¿Es correcta?: " + expresion6.controlCorchetes());
    }
}
