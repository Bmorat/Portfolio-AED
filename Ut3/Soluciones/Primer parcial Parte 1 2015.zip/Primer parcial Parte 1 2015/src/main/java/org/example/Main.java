package org.example;

public class Main {
    public static void main(String[] args) {
        // Ejercicio 1: Mezclar dos listas ordenadas
        ListaOrdenada<Integer> lista1 = new ListaOrdenada<>();
        ListaOrdenada<Integer> lista2 = new ListaOrdenada<>();

        lista1.insertar(1);
        lista1.insertar(3);
        lista1.insertar(5);

        lista2.insertar(2);
        lista2.insertar(4);
        lista2.insertar(6);

        System.out.println("Lista 1:");
        lista1.imprimir();

        System.out.println("Lista 2:");
        lista2.imprimir();

        ListaOrdenada<Integer> listaMezclada = lista1.mezclarCon(lista2);

        System.out.println("Lista Mezclada:");
        listaMezclada.imprimir();

        // Ejercicio 2: Eliminar duplicados de una lista
        Lista<Integer> lista = new Lista<>();

        lista.insertar(1);
        lista.insertar(3);
        lista.insertar(2);
        lista.insertar(3);
        lista.insertar(4);
        lista.insertar(2);
        lista.insertar(5);

        System.out.println("Lista antes de eliminar duplicados:");
        lista.imprimir();

        lista.eliminarDuplicados();

        System.out.println("Lista después de eliminar duplicados:");
        lista.imprimir();
    }
}
