package org.example;

public class ListaOrdenada<T extends Comparable<T>> {
    private Nodo<T> primero;

    public ListaOrdenada() {
        primero = null;
    }

    public boolean esVacia() {
        return primero == null;
    }

    public void insertar(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (primero == null || primero.getDato().compareTo(dato) > 0) {
            nuevo.setSiguiente(primero);
            primero = nuevo;
        } else {
            Nodo<T> actual = primero;
            while (actual.getSiguiente() != null && actual.getSiguiente().getDato().compareTo(dato) < 0) {
                actual = actual.getSiguiente();
            }
            nuevo.setSiguiente(actual.getSiguiente());
            actual.setSiguiente(nuevo);
        }
    }

    public ListaOrdenada<T> mezclarCon(ListaOrdenada<T> otraLista) {
        ListaOrdenada<T> listaMezclada = new ListaOrdenada<>();
        Nodo<T> actual1 = this.primero;
        Nodo<T> actual2 = otraLista.primero;

        while (actual1 != null && actual2 != null) {
            if (actual1.getDato().compareTo(actual2.getDato()) <= 0) {
                listaMezclada.insertar(actual1.getDato());
                actual1 = actual1.getSiguiente();
            } else {
                listaMezclada.insertar(actual2.getDato());
                actual2 = actual2.getSiguiente();
            }
        }

        while (actual1 != null) {
            listaMezclada.insertar(actual1.getDato());
            actual1 = actual1.getSiguiente();
        }

        while (actual2 != null) {
            listaMezclada.insertar(actual2.getDato());
            actual2 = actual2.getSiguiente();
        }

        this.primero = null;
        otraLista.primero = null;

        return listaMezclada;
    }

    public void imprimir() {
        Nodo<T> actual = primero;
        while (actual != null) {
            System.out.print(actual.getDato() + " ");
            actual = actual.getSiguiente();
        }
        System.out.println();
    }
}

