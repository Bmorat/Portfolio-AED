package org.example;

public class Lista<T extends Comparable<T>> {
    private Nodo<T> primero;

    public Lista() {
        primero = null;
    }

    public boolean esVacia() {
        return primero == null;
    }

    public void insertar(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        nuevo.setSiguiente(primero);
        primero = nuevo;
    }

    public void eliminarDuplicados() {
        Nodo<T> actual = primero;

        while (actual != null && actual.getSiguiente() != null) {
            Nodo<T> comparador = actual;

            while (comparador.getSiguiente() != null) {
                if (actual.getDato().compareTo(comparador.getSiguiente().getDato()) == 0) {
                    comparador.setSiguiente(comparador.getSiguiente().getSiguiente());
                } else {
                    comparador = comparador.getSiguiente();
                }
            }

            actual = actual.getSiguiente();
        }
    }

    public void imprimir() {
        Nodo<T> actual = primero;
        while (actual != null) {
            System.out.print(actual.getDato() + " ");
            actual = actual.getSiguiente();
        }
        System.out.println();
    }
}
