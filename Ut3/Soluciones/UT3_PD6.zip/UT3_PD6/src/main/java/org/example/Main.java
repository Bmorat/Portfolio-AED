package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Lista<String> listaSucursales = new Lista<>();

        // Cargar las sucursales iniciales
        cargarSucursales("src/main/resources/sucursales.txt", listaSucursales);

        System.out.println("Cantidad de sucursales: " + listaSucursales.cantElementos());
        System.out.println("Sucursales:");
        System.out.println(listaSucursales.imprimir(", "));

        // Eliminar la ciudad "Chicago" (nota: no está en la lista inicial)
        listaSucursales.eliminar("Chicago");
        System.out.println("\nDespués de eliminar 'Chicago':");
        System.out.println(listaSucursales.imprimir(", "));

        // Buscar la ciudad "Hong Kong" y mostrar la ciudad siguiente
        Nodo<String> nodoHongKong = listaSucursales.buscar("Hong Kong");
        if (nodoHongKong != null && nodoHongKong.getSiguiente() != null) {
            System.out.println("La ciudad que sigue a 'Hong Kong' es: " + nodoHongKong.getSiguiente().getDato());
        } else {
            System.out.println("'Hong Kong' no tiene ciudad siguiente en la lista.");
        }

        // Levantar un segundo archivo "suc2.txt" y eliminar "Shenzhen" y "Tokio"
        cargarSucursales("src/main/resources/suc2.txt", listaSucursales);
        listaSucursales.eliminar("Shenzhen");
        listaSucursales.eliminar("Tokio");

        System.out.println("\nDespués de eliminar 'Shenzhen' y 'Tokio':");
        System.out.println("Cantidad de sucursales: " + listaSucursales.cantElementos());
        System.out.println(listaSucursales.imprimir(", "));

        // Levantar un tercer archivo "suc3.txt" y usar Imprimir(";_")
        cargarSucursales("src/main/resources/suc3.txt", listaSucursales);
        System.out.println("\nSucursales después de cargar 'suc3.txt':");
        System.out.println(listaSucursales.imprimir(";_"));
    }

    private static void cargarSucursales(String filePath, Lista<String> lista) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String ciudad = linea.trim().replace("\uFEFF", "");
                if (!ciudad.isEmpty() && lista.buscar(ciudad) == null) {
                    lista.insertar(new Nodo<>(ciudad));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}