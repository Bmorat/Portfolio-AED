package org.example;

public class Pila<T> extends Lista<T> implements IPila<T> {

    @Override
    public void apilar(T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(dato);
        nuevoNodo.setSiguiente(getPrimero());
        setPrimero(nuevoNodo);
    }

    @Override
    public T desapilar() {
        if (esVacia()) {
            return null;
        }
        Nodo<T> primero = getPrimero();
        setPrimero(primero.getSiguiente());
        return primero.getDato();
    }

    @Override
    public T tope() {
        if (esVacia()) {
            return null;
        }
        return getPrimero().getDato();
    }

    @Override
    public int tamanio() {
        return cantElementos();
    }
}



