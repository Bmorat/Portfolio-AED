package org.example;

public class Main {
    public static void main(String[] args) {
        // Demostración del uso de la Pila
        Pila<String> pila = new Pila<>();
        pila.apilar("Elemento 1");
        pila.apilar("Elemento 2");
        pila.apilar("Elemento 3");

        System.out.println("Contenido de la pila:");
        System.out.println(pila.imprimir());

        System.out.println("Elemento desapilado: " + pila.desapilar());
        System.out.println("Contenido de la pila después de desapilar:");
        System.out.println(pila.imprimir());

        // Demostración del uso de la Cola
        Cola<String> cola = new Cola<>();
        cola.encolar("Elemento A");
        cola.encolar("Elemento B");
        cola.encolar("Elemento C");

        System.out.println("Contenido de la cola:");
        System.out.println(cola.imprimir());

        System.out.println("Elemento desencolado: " + cola.desencolar());
        System.out.println("Contenido de la cola después de desencolar:");
        System.out.println(cola.imprimir());
    }
}



