package org.example;

public class Lista<T> {
    private Nodo<T> primero;

    public Lista() {
        primero = null;
    }

    public void insertar(Nodo<T> unNodo) {
        if (esVacia()) {
            primero = unNodo;
        } else {
            Nodo<T> aux = primero;
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(unNodo);
        }
    }

    public boolean esVacia() {
        return primero == null;
    }

    public int cantElementos() {
        int count = 0;
        Nodo<T> temp = primero;
        while (temp != null) {
            count++;
            temp = temp.getSiguiente();
        }
        return count;
    }

    public void setPrimero(Nodo<T> unNodo) {
        this.primero = unNodo;
    }

    public Nodo<T> getPrimero() {
        return primero;
    }

    public String imprimir() {
        StringBuilder sb = new StringBuilder();
        Nodo<T> temp = primero;
        while (temp != null) {
            sb.append(temp.getDato()).append(" ");
            temp = temp.getSiguiente();
        }
        return sb.toString().trim();
    }
}

