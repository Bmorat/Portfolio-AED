package org.example;

public interface IPila<T> {
    void apilar(T dato);
    T desapilar();
    boolean esVacia();
    int tamanio();
    T tope();
}


