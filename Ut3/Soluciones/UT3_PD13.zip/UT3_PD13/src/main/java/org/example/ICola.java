package org.example;

public interface ICola<T> {
    void encolar(T dato);
    T desencolar();
    boolean esVacia();
    int tamanio();
    T frente();
}


