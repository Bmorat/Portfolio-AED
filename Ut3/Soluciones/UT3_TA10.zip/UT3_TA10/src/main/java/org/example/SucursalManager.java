package org.example;

import java.util.LinkedList;

public class SucursalManager {
    private LinkedList<String> sucursales;

    public SucursalManager() {
        sucursales = new LinkedList<>();
    }

    public void cargarSucursales(String nombreArchivo) {
        System.out.println("Cargando archivo: " + nombreArchivo);
        String[] lineas = ManejadorArchivosGenerico.leerArchivo(nombreArchivo);
        for (String linea : lineas) {
            String ciudad = linea.trim();
            if (!sucursales.contains(ciudad)) {
                sucursales.add(ciudad);
                System.out.println("Agregada ciudad: " + ciudad);
            }
        }
    }

    public void agregarSucursal(String ciudad) {
        if (!sucursales.contains(ciudad)) {
            sucursales.add(ciudad);
            System.out.println("Agregada ciudad: " + ciudad);
        }
    }

    public boolean buscarSucursal(String ciudad) {
        return sucursales.contains(ciudad);
    }

    public boolean quitarSucursal(String ciudad) {
        boolean eliminado = sucursales.remove(ciudad);
        if (eliminado) {
            System.out.println("Eliminada ciudad: " + ciudad);
        }
        return eliminado;
    }

    public void listarSucursales() {
        for (String sucursal : sucursales) {
            System.out.println(sucursal);
        }
    }

    public int cantidadSucursales() {
        return sucursales.size();
    }

    public boolean esVacio() {
        return sucursales.isEmpty();
    }

    public String obtenerSiguiente(String ciudad) {
        int index = sucursales.indexOf(ciudad);
        if (index != -1 && index + 1 < sucursales.size()) {
            return sucursales.get(index + 1);
        }
        return "No hay siguiente ciudad";
    }

    public void imprimir(String separador) {
        System.out.println(String.join(separador, sucursales));
    }
}




