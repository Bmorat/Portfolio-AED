package org.example;

import java.io.*;
import java.util.ArrayList;

public class ManejadorArchivosGenerico {

    public static void escribirArchivo(String nombreCompletoArchivo, String[] listaLineasArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreCompletoArchivo))) {
            for (String lineaActual : listaLineasArchivo) {
                bw.write(lineaActual);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo " + nombreCompletoArchivo);
            e.printStackTrace();
        }
    }

    public static String[] leerArchivo(String nombreArchivo) {
        ArrayList<String> listaLineasArchivo = new ArrayList<>();
        try (InputStream is = ManejadorArchivosGenerico.class.getResourceAsStream("/" + nombreArchivo);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String lineaActual = br.readLine();
            while (lineaActual != null) {
                listaLineasArchivo.add(lineaActual);
                lineaActual = br.readLine();
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo " + nombreArchivo);
            e.printStackTrace();
        }
        return listaLineasArchivo.toArray(new String[0]);
    }
}
