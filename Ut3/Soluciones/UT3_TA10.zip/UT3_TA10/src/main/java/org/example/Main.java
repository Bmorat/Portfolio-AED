package org.example;

public class Main {
    public static void main(String[] args) {
        SucursalManager manager = new SucursalManager();

        // 1. Cargar el archivo sucursales.txt
        manager.cargarSucursales("sucursales.txt");
        System.out.println("Cantidad de sucursales: " + manager.cantidadSucursales());
        manager.listarSucursales();

        // 2. Eliminar la ciudad “Chicago” y listar nuevamente las sucursales
        manager.quitarSucursal("Chicago");
        System.out.println("Ciudad siguiente a 'Hong Kong': " + manager.obtenerSiguiente("Hong Kong"));

        // 3. Levantar el segundo archivo suc2.txt, eliminar "Shenzhen" y "Tokio"
        manager.cargarSucursales("suc2.txt");
        manager.quitarSucursal("Shenzhen");
        manager.quitarSucursal("Tokio");
        manager.listarSucursales();

        // 4. Levantar el tercer archivo suc3.txt y usar el método imprimir
        manager.cargarSucursales("suc3.txt");
        manager.imprimir(";_");
    }
}



