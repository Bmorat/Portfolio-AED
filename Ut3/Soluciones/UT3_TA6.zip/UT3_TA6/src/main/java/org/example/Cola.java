package org.example;

public class Cola<T> extends Lista<T> implements ICola<T> {

    @Override
    public void encolar(T dato) {
        insertar(new Nodo<>(dato));
    }

    @Override
    public T desencolar() {
        if (esVacia()) {
            return null;
        }
        Nodo<T> primero = getPrimero();
        setPrimero(primero.getSiguiente());
        return primero.getDato();
    }

    @Override
    public T frente() {
        if (esVacia()) {
            return null;
        }
        return getPrimero().getDato();
    }

    @Override
    public int tamanio() {
        return cantElementos();
    }
}



