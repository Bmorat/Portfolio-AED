package org.example;

public class Main {
    public static void main(String[] args) {
        String secuencia1 = "{}{{}}";
        String secuencia2 = "{{}{{}";

        System.out.println("Secuencia 1 es correcta: " + controlCorchetes(secuencia1));
        System.out.println("Secuencia 2 es correcta: " + controlCorchetes(secuencia2));
    }

    public static boolean controlCorchetes(String listaDeEntrada) {
        Pila<Character> pila = new Pila<>();

        for (char caracter : listaDeEntrada.toCharArray()) {
            if (caracter == '{') {
                pila.apilar(caracter);
            } else if (caracter == '}') {
                if (pila.esVacia()) {
                    return false;
                }
                pila.desapilar();
            }
        }

        return pila.esVacia();
    }
}
