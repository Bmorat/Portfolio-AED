package org.example;

public interface ILista<T extends Comparable<T>> {
    public void retirarDuplicados();
    public void insertar(T dato);
    public void imprimir(String separador);
}
