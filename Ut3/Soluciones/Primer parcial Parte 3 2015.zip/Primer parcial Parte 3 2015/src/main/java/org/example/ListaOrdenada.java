package org.example;

import java.util.LinkedList;

public class ListaOrdenada<T extends Comparable<T>> implements IListaOrdenada<T> {
    private LinkedList<T> elementos;

    public ListaOrdenada() {
        elementos = new LinkedList<>();
    }

    @Override
    public IListaOrdenada<T> mezclar(IListaOrdenada<T> otraLista) {
        ListaOrdenada<T> listaMezclada = new ListaOrdenada<>();
        while (!elementos.isEmpty() && !((ListaOrdenada<T>) otraLista).elementos.isEmpty()) {
            if (elementos.peek().compareTo(((ListaOrdenada<T>) otraLista).elementos.peek()) <= 0) {
                listaMezclada.insertar(elementos.poll());
            } else {
                listaMezclada.insertar(((ListaOrdenada<T>) otraLista).elementos.poll());
            }
        }
        while (!elementos.isEmpty()) {
            listaMezclada.insertar(elementos.poll());
        }
        while (!((ListaOrdenada<T>) otraLista).elementos.isEmpty()) {
            listaMezclada.insertar(((ListaOrdenada<T>) otraLista).elementos.poll());
        }
        return listaMezclada;
    }

    @Override
    public void insertar(T dato) {
        elementos.add(dato);
        elementos.sort(Comparable::compareTo);
    }

    @Override
    public void imprimir(String separador) {
        System.out.println(String.join(separador, elementos.toString()));
    }
}
