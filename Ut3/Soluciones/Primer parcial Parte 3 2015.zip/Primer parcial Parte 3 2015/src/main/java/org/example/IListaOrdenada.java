package org.example;

public interface IListaOrdenada<T extends Comparable<T>> {
    public IListaOrdenada<T> mezclar(IListaOrdenada<T> otraLista);
    public void insertar(T dato);
    public void imprimir(String separador);
}
