package org.example;

import java.util.LinkedList;

public class Lista<T extends Comparable<T>> implements ILista<T> {
    private LinkedList<T> elementos;

    public Lista() {
        elementos = new LinkedList<>();
    }

    @Override
    public void retirarDuplicados() {
        LinkedList<T> elementosUnicos = new LinkedList<>();
        for (T elemento : elementos) {
            if (!elementosUnicos.contains(elemento)) {
                elementosUnicos.add(elemento);
            }
        }
        elementos = elementosUnicos;
    }

    @Override
    public void insertar(T dato) {
        elementos.add(dato);
    }

    @Override
    public void imprimir(String separador) {
        System.out.println(String.join(separador, elementos.toString()));
    }
}

