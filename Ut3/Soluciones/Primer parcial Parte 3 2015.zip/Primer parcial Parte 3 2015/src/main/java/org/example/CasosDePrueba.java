package org.example;

public class CasosDePrueba {
    public static void main(String[] args) {
        // Test caso para mezclar listas ordenadas
        ListaOrdenada<Integer> lista1 = new ListaOrdenada<>();
        ListaOrdenada<Integer> lista2 = new ListaOrdenada<>();

        lista1.insertar(1);
        lista1.insertar(3);
        lista1.insertar(5);

        lista2.insertar(2);
        lista2.insertar(4);
        lista2.insertar(6);

        IListaOrdenada<Integer> listaMezclada = lista1.mezclar(lista2);
        listaMezclada.imprimir(","); // Esperado: 1,2,3,4,5,6

        // Test caso para retirar duplicados
        Lista<Integer> lista = new Lista<>();
        lista.insertar(5);
        lista.insertar(2);
        lista.insertar(4);
        lista.insertar(3);
        lista.insertar(2);
        lista.insertar(3);
        lista.insertar(1);

        lista.retirarDuplicados();
        lista.imprimir(","); // Esperado: 5,2,4,3,1
    }
}
