package org.example;

public class Parcial1 {
    public static void main(String[] args) {
        // Elegir uno de los métodos para implementar y mostrar su funcionamiento
        // Método de IListaOrdenada: mezclar
        ListaOrdenada<Integer> lista1 = new ListaOrdenada<>();
        ListaOrdenada<Integer> lista2 = new ListaOrdenada<>();

        lista1.insertar(1);
        lista1.insertar(2);
        lista1.insertar(4);
        lista1.insertar(5);
        lista1.insertar(8);
        lista1.insertar(9);

        lista2.insertar(2);
        lista2.insertar(3);
        lista2.insertar(6);
        lista2.insertar(7);

        IListaOrdenada<Integer> listaMezclada = lista1.mezclar(lista2);

        System.out.print("Lista 1: ");
        lista1.imprimir(",");
        System.out.print("Lista 2: ");
        lista2.imprimir(",");
        System.out.print("Lista Mezclada: ");
        listaMezclada.imprimir(",");

        // Método de ILista: retirarDuplicados
        Lista<Integer> lista = new Lista<>();

        lista.insertar(1);
        lista.insertar(2);
        lista.insertar(3);
        lista.insertar(3);
        lista.insertar(3);
        lista.insertar(4);
        lista.insertar(5);
        lista.insertar(6);
        lista.insertar(7);
        lista.insertar(7);
        lista.insertar(8);

        System.out.print("Lista antes de retirar duplicados: ");
        lista.imprimir(",");
        lista.retirarDuplicados();
        System.out.print("Lista después de retirar duplicados: ");
        lista.imprimir(",");
    }
}
