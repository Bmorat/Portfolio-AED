package org.example;

public class Lista<T> implements ILista<T> {
    private Nodo<T> primero;

    public Lista() {
        primero = null;
    }

    @Override
    public void insertar(Nodo<T> nodo) {
        if (esVacia()) {
            primero = nodo;
        } else {
            Nodo<T> temp = primero;
            while (temp.getSiguiente() != null) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(nodo);
        }
        System.out.println("Insertado: " + nodo.getDato());
    }

    @Override
    public Nodo<T> buscar(Comparable clave) {
        Nodo<T> temp = primero;
        while (temp != null) {
            if (temp.getEtiqueta().equals(clave)) {
                return temp;
            }
            temp = temp.getSiguiente();
        }
        return null;
    }

    @Override
    public boolean eliminar(Comparable clave) {
        if (esVacia()) {
            return false;
        }

        if (primero.getEtiqueta().equals(clave)) {
            primero = primero.getSiguiente();
            System.out.println("Eliminado: " + clave);
            return true;
        }

        Nodo<T> temp = primero;
        while (temp.getSiguiente() != null && !temp.getSiguiente().getEtiqueta().equals(clave)) {
            temp = temp.getSiguiente();
        }

        if (temp.getSiguiente() == null) {
            return false;
        }

        temp.setSiguiente(temp.getSiguiente().getSiguiente());
        System.out.println("Eliminado: " + clave);
        return true;
    }

    @Override
    public String imprimir(String separador) {
        StringBuilder sb = new StringBuilder();
        Nodo<T> temp = primero;
        while (temp != null) {
            sb.append(temp.getDato().toString()).append(separador);
            temp = temp.getSiguiente();
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - separador.length()) : "";
    }

    @Override
    public int cantElementos() {
        int count = 0;
        Nodo<T> temp = primero;
        while (temp != null) {
            count++;
            temp = temp.getSiguiente();
        }
        return count;
    }

    @Override
    public boolean esVacia() {
        return primero == null;
    }

    @Override
    public void setPrimero(Nodo<T> unNodo) {
        this.primero = unNodo;
    }

    @Override
    public Nodo<T> getPrimero() {
        return primero;
    }
}


