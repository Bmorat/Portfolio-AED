package org.example;


public interface INodo<T> {
    T getDato();
    void setDato(T dato);
    Nodo<T> getSiguiente();
    void setSiguiente(Nodo<T> nodo);
    void imprimir();
    Comparable getEtiqueta();
}

