package org.example;

public class Conjunto<T extends Comparable<T>> extends Lista<T> implements IConjunto<T> {

    @Override
    public IConjunto<T> union(IConjunto<T> otroConjunto) {
        IConjunto<T> resultado = new Conjunto<>();
        Nodo<T> actual1 = this.getPrimero();
        Nodo<T> actual2 = otroConjunto.getPrimero();

        while (actual1 != null && actual2 != null) {
            int comparacion = actual1.getEtiqueta().compareTo(actual2.getEtiqueta());
            if (comparacion < 0) {
                resultado.insertar(new Nodo<>(actual1.getEtiqueta(), actual1.getDato()));
                actual1 = actual1.getSiguiente();
            } else if (comparacion > 0) {
                resultado.insertar(new Nodo<>(actual2.getEtiqueta(), actual2.getDato()));
                actual2 = actual2.getSiguiente();
            } else {
                resultado.insertar(new Nodo<>(actual1.getEtiqueta(), actual1.getDato()));
                actual1 = actual1.getSiguiente();
                actual2 = actual2.getSiguiente();
            }
        }

        while (actual1 != null) {
            resultado.insertar(new Nodo<>(actual1.getEtiqueta(), actual1.getDato()));
            actual1 = actual1.getSiguiente();
        }

        while (actual2 != null) {
            resultado.insertar(new Nodo<>(actual2.getEtiqueta(), actual2.getDato()));
            actual2 = actual2.getSiguiente();
        }

        return resultado;
    }

    @Override
    public IConjunto<T> interseccion(IConjunto<T> otroConjunto) {
        IConjunto<T> resultado = new Conjunto<>();
        Nodo<T> actual1 = this.getPrimero();
        Nodo<T> actual2 = otroConjunto.getPrimero();

        while (actual1 != null && actual2 != null) {
            int comparacion = actual1.getEtiqueta().compareTo(actual2.getEtiqueta());
            if (comparacion < 0) {
                actual1 = actual1.getSiguiente();
            } else if (comparacion > 0) {
                actual2 = actual2.getSiguiente();
            } else {
                resultado.insertar(new Nodo<>(actual1.getEtiqueta(), actual1.getDato()));
                actual1 = actual1.getSiguiente();
                actual2 = actual2.getSiguiente();
            }
        }

        return resultado;
    }
}
