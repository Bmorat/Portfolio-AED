package org.example;

public class Main {
    public static void main(String[] args) {
        IConjunto<TAlumno> cursoAED1 = new Conjunto<>();
        IConjunto<TAlumno> cursoPF = new Conjunto<>();

        TAlumno alumno1 = new TAlumno("1234", "Juan", "Pérez");
        TAlumno alumno2 = new TAlumno("5678", "Ana", "Gómez");
        TAlumno alumno3 = new TAlumno("9101", "Luis", "Martínez");
        TAlumno alumno4 = new TAlumno("1121", "María", "López");

        cursoAED1.insertar(new Nodo<>(alumno1.getCedula(), alumno1));
        cursoAED1.insertar(new Nodo<>(alumno2.getCedula(), alumno2));

        cursoPF.insertar(new Nodo<>(alumno2.getCedula(), alumno2));
        cursoPF.insertar(new Nodo<>(alumno3.getCedula(), alumno3));
        cursoPF.insertar(new Nodo<>(alumno4.getCedula(), alumno4));

        IConjunto<TAlumno> unionCursos = cursoAED1.union(cursoPF);
        IConjunto<TAlumno> interseccionCursos = cursoAED1.interseccion(cursoPF);

        System.out.println("Alumnos en cualquiera de los dos cursos:");
        System.out.println(unionCursos.imprimir(", "));

        System.out.println("Alumnos en ambos cursos:");
        System.out.println(interseccionCursos.imprimir(", "));
    }
}

