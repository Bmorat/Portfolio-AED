package org.example;

import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        Curso basicoIng = new Curso("BasicoIng");
        Curso basicoEmp = new Curso("BasicoEmp");

        cargarAlumnosDesdeArchivo("src/main/resources/basico-ing.txt", basicoIng);
        cargarAlumnosDesdeArchivo("src/main/resources/basico-emp.txt", basicoEmp);

        Conjunto<Alumno> integrador101 = basicoIng.getAlumnos().union(basicoEmp.getAlumnos());
        guardarAlumnosEnArchivo("src/main/resources/integrador101.txt", integrador101);

        Conjunto<Alumno> exigente102 = basicoIng.getAlumnos().interseccion(basicoEmp.getAlumnos());
        guardarAlumnosEnArchivo("src/main/resources/exigente102.txt", exigente102);

        System.out.println("Integrador 101:");
        integrador101.imprimir(" ");

        System.out.println("Exigente 102:");
        exigente102.imprimir(" ");
    }

    private static void cargarAlumnosDesdeArchivo(String nombreArchivo, Curso curso) {
        String[] lineas = ManejadorArchivosGenerico.leerArchivo(nombreArchivo);
        for (String linea : lineas) {
            String[] datos = linea.split(",");
            Alumno alumno = new Alumno(Integer.parseInt(datos[0].trim()), datos[1].trim());
            curso.agregarAlumno(alumno);
        }
    }

    private static void guardarAlumnosEnArchivo(String nombreArchivo, Conjunto<Alumno> conjunto) {
        List<String> lineas = new ArrayList<>();
        for (Alumno alumno : conjunto.getElementos()) {
            lineas.add(alumno.toString());
        }
        ManejadorArchivosGenerico.escribirArchivo(nombreArchivo, lineas.toArray(new String[0]));
    }
}

