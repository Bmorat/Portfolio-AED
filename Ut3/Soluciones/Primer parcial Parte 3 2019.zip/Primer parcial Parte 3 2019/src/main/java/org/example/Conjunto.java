package org.example;

import java.util.ArrayList;
import java.util.List;

public class Conjunto<T> implements IConjunto<T> {
    private List<T> elementos;

    public Conjunto() {
        this.elementos = new ArrayList<>();
    }

    @Override
    public void insertar(T elemento) {
        if (!elementos.contains(elemento)) {
            elementos.add(elemento);
        }
    }

    @Override
    public Conjunto<T> union(Conjunto<T> otroConjunto) {
        Conjunto<T> resultado = new Conjunto<>();
        resultado.elementos.addAll(this.elementos);
        for (T elemento : otroConjunto.elementos) {
            if (!resultado.elementos.contains(elemento)) {
                resultado.insertar(elemento);
            }
        }
        return resultado;
    }

    @Override
    public Conjunto<T> interseccion(Conjunto<T> otroConjunto) {
        Conjunto<T> resultado = new Conjunto<>();
        for (T elemento : this.elementos) {
            if (otroConjunto.elementos.contains(elemento)) {
                resultado.insertar(elemento);
            }
        }
        return resultado;
    }

    public List<T> getElementos() {
        return elementos;
    }

    @Override
    public void imprimir(String separador) {
        for (T elemento : elementos) {
            System.out.print(elemento + separador);
        }
        System.out.println();
    }
}



