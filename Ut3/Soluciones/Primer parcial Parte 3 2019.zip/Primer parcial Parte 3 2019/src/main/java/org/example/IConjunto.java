package org.example;

public interface IConjunto<T> {
    void insertar(T elemento);
    Conjunto<T> union(Conjunto<T> otroConjunto);
    Conjunto<T> interseccion(Conjunto<T> otroConjunto);
    void imprimir(String separador);
}


