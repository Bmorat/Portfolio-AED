package org.example;

import java.util.ArrayList;
import java.util.List;

public class Curso {
    private String nombre;
    private Conjunto<Alumno> alumnos;

    public Curso(String nombre) {
        this.nombre = nombre;
        this.alumnos = new Conjunto<>();
    }

    public void agregarAlumno(Alumno alumno) {
        alumnos.insertar(alumno);
    }

    public Conjunto<Alumno> getAlumnos() {
        return alumnos;
    }

    public void guardarAlumnosEnArchivo(String nombreArchivo) {
        List<String> lineas = new ArrayList<>();
        for (Alumno alumno : alumnos.getElementos()) {
            lineas.add(alumno.toString());
        }
        ManejadorArchivosGenerico.escribirArchivo(nombreArchivo, lineas.toArray(new String[0]));
    }
}


