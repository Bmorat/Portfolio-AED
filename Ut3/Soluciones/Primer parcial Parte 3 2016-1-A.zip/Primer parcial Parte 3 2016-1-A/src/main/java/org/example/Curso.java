package org.example;

public class Curso {
    private String nombre;
    private IConjunto<Integer> listaDeClase;

    public Curso(String nombre) {
        this.nombre = nombre;
        this.listaDeClase = new Conjunto<>();
    }

    public void agregarAlumno(Integer alumno) {
        listaDeClase.insertar(alumno);
    }

    public IConjunto<Integer> enEsteUOtro(Curso otroCurso) {
        return listaDeClase.diferenciaSimetrica(otroCurso.listaDeClase);
    }

    public IConjunto<Integer> getListaDeClase() {
        return listaDeClase;
    }
}



