package org.example;

public interface IConjunto<T> {
    void insertar(T elemento);
    IConjunto<T> diferenciaSimetrica(IConjunto<T> otroConjunto);
    void imprimir(String separador);
}

