package org.example;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Curso AED1 = new Curso("AED1");
        Curso MD = new Curso("MD");

        String[] alumnosAED1 = ManejadorArchivosGenerico.leerArchivo("src/main/resources/alumnosAED1.txt");
        for (String alumno : alumnosAED1) {
            AED1.agregarAlumno(Integer.parseInt(alumno.trim()));
        }

        String[] alumnosMD = ManejadorArchivosGenerico.leerArchivo("src/main/resources/alumnosMD.txt");
        for (String alumno : alumnosMD) {
            MD.agregarAlumno(Integer.parseInt(alumno.trim()));
        }

        IConjunto<Integer> diferenciaSimetrica = AED1.enEsteUOtro(MD);
        List<String> salida = new ArrayList<>();
        for (Integer alumno : ((Conjunto<Integer>) diferenciaSimetrica).getElementos()) {
            salida.add(alumno.toString());
        }
        ManejadorArchivosGenerico.escribirArchivo("src/main/resources/salidaSimetrica.txt", salida.toArray(new String[0]));

        System.out.println("Diferencia simétrica:");
        diferenciaSimetrica.imprimir(",");
    }
}
